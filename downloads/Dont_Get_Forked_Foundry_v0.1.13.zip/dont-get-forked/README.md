# Don't Get Forked for Foundry VTT, release 0.1.13

Game design & writing: Richard Moore.

## Installing by hand

1. Unzip this file into Foundry's `Data/systems` folder, so you get `Data/systems/dont-get-forked/system.json`.
2. Restart Foundry.
3. Pick Don't Get Forked when you create a world.
