/**
 * DON'T GET FORKED — Chases (pure, Foundry-free)
 * ----------------------------------------------
 * One chase at a time, kept in the raid state (module/logic/raid.mjs) and
 * written only by the Storyteller's client. Every function returns a new chase;
 * nothing is mutated. The roll dialog asks rollContext() what a member rolls
 * this round (the ground's traits, the mob's Difficulty, the Weakness); the GM
 * records each roll and resolves the round when everyone has rolled.
 *
 *   chase = { id, kind: "local" | "final", cause: "caught" | "limit" | "dawn" | "manual",
 *             label, turn, groupId, where,
 *             members: [{ actorId, name, entityKey, perk, timing }],   // those still running
 *             gaveUp: [{ actorId, name, round }],                       // D2: gave up (captured, no roll)
 *             lead, start, escape, round, mob, ground: { face, key, traits } | null,
 *             roundCap,   // 2026-10-21: a local chase's most rounds (6; 0 = no cap: the switch off, the final flight, an older chase)
 *             capped,     // the round cap ended it (escaped with a Lead of 2 or more, otherwise cornered)
 *             rolls: { [actorId]: { messageId, band, critical, rise, riseKeys, overdraws } },
 *             history: [{ round, face, key, mob, rolls: [{ actorId, name, band, critical, rise, riseKeys, overdraws }], move, lead, capped }],
 *             extraOverdraws: [{ messageId, n, actorId }],   // overdraws made in the chase outside a chase roll (the sheet)
 *             endRise: null | { rise, keys, overdraws, overdrawRise, total, applied, beforeHunt },
 *             outcome: "" | "escaped" | "cornered" | "gaveUp" | "ended" | "dropped" }
 *
 * Source: rulebook Chapter 6 (The Lead; The Ground; One chase, one rise; Your
 * Weakness; The Local Chase; Giving up; The Final Flight and the Majority Rule; the
 * chase table) and Chapter 5 (At the Limit). Perks from Chapter 2 via DGF.perkRules:
 * Wall-Crawler and Fly by Night (a trait you can always roll in a chase; Wall-Crawler's Nimble
 * one size bigger there is the roll plan's, module/logic/roll-plan.mjs), Night Runner
 * and Fear the Curse (when you flee alone: Lead 2, the mob 1 easier; F14: `aloneOnly`,
 * judged when the chase starts), Fetch (the final flight starts at Lead 3), Already Dead
 * (cornered in a local chase, you lose your next Turn instead).
 * D1 (2026-10-19): a local chase's mob is set when it starts and stays put, and the
 * chase raises Suspicion once, when it ends, by the biggest trigger among all its rolls
 * (every runner's), plus +2 for each overdraw made in it (D3): chaseRise().
 * 2026-10-21 (the v0.2 review's decisions): the local mob is at most 11 (rules.mjs); a local chase lasts at most 6
 * rounds, then a Lead of 2 or more escapes and anything less is cornered (`roundCap`, resolveRound); a runner overdraws
 * at most once in a local chase (overdrawsBy, read by the roll plan); a runner gives up only once the round's ground is
 * read (canGiveUp); a Huge piece one of whose carriers is caught can't move until the chase is over (holdsPiece).
 */
import { DGF } from "../config.mjs";
import { leadMove, majorityMove, localMobDifficulty, weaknessInPlay } from "./rules.mjs";
import { findEntity } from "./entity.mjs";

const perkRule = (perk) => DGF.perkRules[perk] ?? {};
export const CHASE_KINDS = Object.freeze(["local", "final"]);

/** A member's Perk value for this chase: a Perk marked `aloneOnly` works only when that Entity flees alone (F14). */
function perkValue(chase, member, key) {
  const r = perkRule(member.perk);
  if (r.aloneOnly && chase.members.length !== 1) return 0;
  return r[key] ?? 0;
}

/** Several fleeing on one Lead in a local chase (caught together in one group check), counting only those still running. */
export function isSharedLocal(chase) {
  return !!chase && chase.kind === "local" && chase.members.length > 1;
}

/** D1: the Suspicion event of a local chase's one rise (it comes when the chase ends). */
export function riseEventId(chase) {
  return `chase:${chase?.id ?? ""}`;
}

/** D1: the outcomes that end a local chase with its one rise (called off and the Limit's own ending aside). */
export const RISE_OUTCOMES = Object.freeze(["escaped", "cornered", "gaveUp"]);

/** A chase member from an Entity actor's id, name and system data (its Perk and its Weakness's timing). */
export function memberOf({ id, name = "", system = {} }) {
  const e = findEntity(system.entityKey);
  return { actorId: id, name, entityKey: system.entityKey ?? "", perk: system.perk ?? "", timing: e?.weakness?.timing ?? "soon" };
}

/** B3: the final flight's escape number, by the town's label (5 on Easy and Standard, 6 on Hard). */
export function finalEscape(label = "standard") {
  return DGF.labels[label]?.finalEscape ?? DGF.lead.finalEscape;
}

/**
 * A new chase. Local: Lead 1, escape at 4 (Night Runner, fleeing alone: starts at Lead 2); D1: the mob's
 * Difficulty is set now, from the Suspicion as the chase starts, and stays put for the whole chase.
 * Final flight: Lead 2, escape at the label's number (B3: 5 on Easy and Standard, 6 on Hard), the mob the
 * label's; Fetch: it starts at Lead 3 (DGF.perkRules finalLead).
 */
export function newChase({ id, kind = "local", cause = "caught", members = [], turn = 0, groupId = "", where = "", label = "standard", suspicion = 0, roundCap = DGF.localRoundCap.rounds }) {
  if (!CHASE_KINDS.includes(kind)) throw new Error(`unknown chase kind: ${kind}`);
  if (!id) throw new Error("a chase needs an id");
  const L = DGF.lead;
  const chase = {
    id, kind, cause, label, turn, groupId, where,
    members: members.map((m) => ({ ...m })),
    gaveUp: [],
    lead: kind === "final" ? L.finalStart : L.localStart,
    start: 0,
    escape: kind === "final" ? finalEscape(label) : L.localEscape,
    round: 1, mob: null, ground: null, rolls: {}, history: [], extraOverdraws: [], endRise: null, outcome: "",
    // 2026-10-21: a local chase lasts at most this many rounds (0: no cap, the Storyteller's switch off); never the final flight
    roundCap: kind === "local" ? Math.max(0, Math.trunc(Number(roundCap)) || 0) : 0, capped: false,
  };
  // Night Runner: "when you flee alone, your local chase starts at Lead 2" (F14); Fetch: the final flight starts at Lead 3.
  const perkLead = Math.max(0, ...chase.members.map((m) => perkValue(chase, m, kind === "final" ? "finalLead" : "localLead")));
  chase.lead = Math.max(chase.lead, perkLead);
  chase.start = chase.lead;
  chase.mob = mobDifficulty(chase, { suspicion, label });
  return chase;
}

/** Is the chase still running? */
export function isRunning(chase) {
  return !!chase && !chase.outcome;
}

/**
 * V24 (Chapters 3 and 4): nothing is dropped in a local chase, loot or furniture: is this Entity in one now (a
 * member of a running local chase, from the moment it's caught until the chase ends)? A final flight isn't one.
 */
export function inLocalChase(chase, actorId) {
  return isRunning(chase) && chase.kind === "local" && chase.members.some((m) => m.actorId === actorId);
}

/** C12: the ground on a d6 face (the traits that work this round). */
export function groundOn(face) {
  const row = DGF.chaseTable[face - 1];
  if (!row) throw new Error(`no ground for ${face}`);
  return { face, key: row.key, traits: [...row.traits] };
}

/**
 * The mob's Difficulty with this Suspicion. Local: 8 plus half the Suspicion (B3), at most 11 (DGF.localMob.max; Fear the Curse,
 * fleeing alone: 1 easier); D1: newChase works it out once, as the chase starts, and it stays put. Final flight:
 * the town's label, whatever the party's size.
 */
export function mobDifficulty(chase, { suspicion = 0, label = "standard" } = {}) {
  if (chase.kind === "final") {
    const L = DGF.labels[label];
    if (!L) throw new Error(`unknown difficulty: ${label}`);
    return L.finalMob;
  }
  const ease = Math.max(0, ...chase.members.map((m) => perkValue(chase, m, "localMobEase")));
  return localMobDifficulty(suspicion) - ease;
}

/**
 * Start the round: roll on the chase table (one roll for everyone). Only before anyone rolls. The mob stays what it
 * was set to when the chase started (D1); a chase kept from before that rule gets it set now, once.
 */
export function startRound(chase, { face, suspicion = 0, label = "standard" }) {
  if (!isRunning(chase)) throw new Error("the chase is over");
  if (Object.keys(chase.rolls).length) throw new Error("someone has already rolled this round");
  return { ...chase, ground: groundOn(face), mob: chase.mob ?? mobDifficulty(chase, { suspicion, label }) };
}

/** The member's record, or null. */
export function memberIn(chase, actorId) {
  return chase?.members.find((m) => m.actorId === actorId) ?? null;
}

/** The traits a member can roll this round: the ground's, plus Wall-Crawler's Nimble or Fly by Night's Wits. */
export function traitsFor(chase, actorId) {
  const m = memberIn(chase, actorId);
  if (!m || !chase.ground) return [];
  const extra = perkRule(m.perk).chaseTrait;
  return extra && !chase.ground.traits.includes(extra) ? [...chase.ground.traits, extra] : [...chase.ground.traits];
}

/**
 * Is the member's Weakness in play this round? By its timing (C3: Always, Soon), or, in the final flight, because the
 * Entity carries the Weakness mark (`marked`: an older world's, from before 2026-10-21, when an overdraw in the flight
 * brought the Weakness; now an overdraw costs a step down of its own, the roll plan's).
 */
export function weaknessFor(chase, actorId, { marked = false } = {}) {
  const m = memberIn(chase, actorId);
  if (!m) return false;
  return weaknessInPlay({ timing: m.timing, round: chase.round, marked: marked && chase.kind === "final" });
}

/**
 * What a member rolls now (for the roll dialog and the roll plan), or why it can't.
 * Returns { ok, reason?, chaseId, kind, round, difficulty, traits, weakness, ground, local }.
 */
export function rollContext(chase, actorId, { marked = false } = {}) {
  const base = { ok: false, chaseId: chase?.id ?? "", kind: chase?.kind ?? "", round: chase?.round ?? 0 };
  if (!isRunning(chase)) return { ...base, reason: "noChase" };
  if (!memberIn(chase, actorId)) return { ...base, reason: "notInChase" };
  if (!chase.ground) return { ...base, reason: "noGround" };
  if (chase.rolls[actorId]) return { ...base, reason: "alreadyRolled" };
  return {
    ...base, ok: true, difficulty: chase.mob, traits: traitsFor(chase, actorId),
    weakness: weaknessFor(chase, actorId, { marked }), ground: { ...chase.ground }, local: chase.kind === "local",
  };
}

/** Who still has to roll this round. */
export function waitingFor(chase) {
  return chase.members.filter((m) => !chase.rolls[m.actorId]);
}

/** Has everyone in the chase rolled this round? */
export function roundDone(chase) {
  return isRunning(chase) && !!chase.ground && chase.members.length > 0 && waitingFor(chase).length === 0;
}

/**
 * Record a member's roll for this round: its band, and (D1) what it adds to the chase's one rise: `rise` (its
 * biggest trigger: Trouble 1, the Monster showing 2), `riseKeys` (which) and `overdraws` (D3: +2 each). The same
 * message again is a no-op; a second roll by the same member, a roll for another round, or after the end is refused.
 * Returns { ok, reason?, chase }.
 */
export function recordRoll(chase, actorId, { messageId = "", round, band, critical = false, rise = 0, riseKeys = [], overdraws = 0 }) {
  if (!isRunning(chase)) return { ok: false, reason: "chaseOver", chase };
  if (!memberIn(chase, actorId)) return { ok: false, reason: "notInChase", chase };
  if (round !== undefined && round !== chase.round) return { ok: false, reason: "otherRound", chase };
  const had = chase.rolls[actorId];
  if (had) return had.messageId === messageId ? { ok: true, reason: "noop", chase } : { ok: false, reason: "alreadyRolled", chase };
  if (!chase.ground) return { ok: false, reason: "noGround", chase };
  const roll = { messageId, band, critical: !!critical, rise: Math.max(0, Number(rise) || 0), riseKeys: [...(riseKeys ?? [])], overdraws: Math.max(0, Math.trunc(Number(overdraws)) || 0) };
  return { ok: true, chase: { ...chase, rolls: { ...chase.rolls, [actorId]: roll } } };
}

/**
 * D1 + D3: an overdraw made in a local chase outside a chase roll (an ability used from the sheet) adds +2 to the
 * chase's one rise (`actorId`: whose, for the one overdraw a runner may make in a local chase). The same message again
 * is a no-op.
 */
export function addOverdraw(chase, { messageId = "", n = 1, actorId = "" }) {
  if (!isRunning(chase) || chase.kind !== "local") return chase;
  const list = chase.extraOverdraws ?? [];
  if (messageId && list.some((o) => o.messageId === messageId)) return chase;
  return { ...chase, extraOverdraws: [...list, { messageId, n: Math.max(0, Math.trunc(Number(n)) || 0), actorId: String(actorId ?? "") }] };
}

/**
 * 2026-10-21 (Chapter 6, The Local Chase): a runner overdraws at most once in a local chase. How many overdraws has this
 * Entity made in this chase so far: on its rolls (every round's) and from the sheet? (0 for a final flight.)
 */
export function overdrawsBy(chase, actorId) {
  if (!chase || chase.kind !== "local" || !actorId) return 0;
  const rolls = [...(chase.history ?? []).flatMap((h) => (h.rolls ?? []).filter((r) => r.actorId === actorId)), ...(chase.rolls?.[actorId] ? [chase.rolls[actorId]] : [])];
  const extra = (chase.extraOverdraws ?? []).filter((o) => o.actorId === actorId);
  return [...rolls, ...extra].reduce((n, r) => n + (r.overdraws ?? r.n ?? 0), 0);
}

/**
 * 2026-10-21 (Chapter 4, Carrying; W4): a Huge piece whose carriers are split by a local chase (one caught, the other
 * not) stays with the other carrier and can't move until the chase is over. `carrierIds`: the Entities carrying the
 * piece now (in the raid, not captured). Held while the chase runs with a carrier in it and a carrier outside it.
 */
export function holdsPiece(chase, carrierIds = []) {
  if (!isRunning(chase) || chase.kind !== "local") return false;
  const ids = [...new Set(carrierIds)];
  return ids.some((id) => !!memberIn(chase, id)) && ids.some((id) => !memberIn(chase, id));
}

/**
 * D1 (Chapter 6, One chase, one rise): what a local chase raises when it ends: the biggest trigger among all its rolls
 * (every runner's, however many rounds; Trouble +1, the Monster showing +2), plus +2 for each overdraw made in it (D3).
 * Returns { rise, keys, overdraws, overdrawRise, total } (keys: the biggest trigger's kind, "trouble" | "monster").
 */
export function chaseRise(chase) {
  const all = [...(chase?.history ?? []).flatMap((h) => h.rolls ?? []), ...Object.values(chase?.rolls ?? {})];
  let rise = 0, keys = new Set(), overdraws = 0;
  for (const r of all) {
    const n = r.rise ?? 0;
    if (n > rise) { rise = n; keys = new Set(r.riseKeys ?? []); }
    else if (n > 0 && n === rise) for (const k of r.riseKeys ?? []) keys.add(k);
    overdraws += r.overdraws ?? 0;
  }
  for (const o of chase?.extraOverdraws ?? []) overdraws += o.n ?? 0;
  const overdrawRise = overdraws * DGF.suspicion.overdraw;
  return { rise, keys: [...keys], overdraws, overdrawRise, total: rise + overdrawRise };
}

/**
 * D2 (Chapter 6, Giving up): may this runner give up now? Only in a running local chase, at the start of a round:
 * once the round's ground is read and before anyone has rolled in it. Returns { ok, reason? }.
 */
export function canGiveUp(chase, actorId) {
  if (!isRunning(chase)) return { ok: false, reason: "noChase" };
  if (chase.kind !== "local") return { ok: false, reason: "notLocal" };
  if (!memberIn(chase, actorId)) return { ok: false, reason: "notInChase" };
  if (!chase.ground) return { ok: false, reason: "noGround" };
  if (Object.keys(chase.rolls ?? {}).length) return { ok: false, reason: "roundStarted" };
  return { ok: true };
}

/**
 * D2: the runner gives up: captured, with no roll (the Storyteller's client captures it). It leaves the runners, so
 * the others carry on and the majority rule counts only those still running; its rolls so far still count toward the
 * chase's one rise. If nobody is left running, the chase is over ("gaveUp"). Returns { ok, reason?, chase }.
 */
export function giveUp(chase, actorId) {
  const can = canGiveUp(chase, actorId);
  if (!can.ok) return { ...can, chase };
  const m = memberIn(chase, actorId);
  const members = chase.members.filter((x) => x.actorId !== actorId);
  const next = { ...chase, members, gaveUp: [...(chase.gaveUp ?? []), { actorId, name: m.name, round: chase.round }] };
  if (!members.length) next.outcome = "gaveUp";
  return { ok: true, chase: next };
}

/**
 * The round's Lead move. One Entity alone in a local chase: Success +1 (a Critical +2),
 * Cost 0, Trouble −1. Several caught together, and every final flight: the majority rule
 * (Successes against Trouble; a Critical counts as two Successes).
 */
export function roundMove(chase) {
  const results = chase.members.map((m) => chase.rolls[m.actorId]).filter(Boolean);
  if (chase.kind === "local" && chase.members.length === 1) return results.length ? leadMove(results[0]) : 0;
  return majorityMove(results);
}

/** The Lead after a move, and whether that ends the chase: reach the escape number and you're clear; reach 0 and you're cornered. */
function applyLead(chase, delta) {
  const raw = chase.lead + delta;
  const outcome = raw >= chase.escape ? "escaped" : raw <= 0 ? "cornered" : "";
  return { lead: Math.max(0, Math.min(chase.escape, raw)), outcome };
}

/**
 * 2026-10-21 (Chapter 6, The Local Chase): a local chase still running after its last round (`roundCap`, 6) ends: a Lead
 * of 2 or more escapes, anything less is cornered. The outcome the cap gives after this round's move, or "".
 */
export function capOutcome(chase, lead = chase.lead) {
  if (chase?.kind !== "local" || !(chase.roundCap > 0) || chase.round < chase.roundCap) return "";
  return lead >= DGF.localRoundCap.escapeAt ? "escaped" : "cornered";
}

/** 2026-10-21: the rounds left before the cap decides a local chase (counting this one), or null with no cap. */
export function roundsLeft(chase) {
  return chase?.kind === "local" && chase.roundCap > 0 ? Math.max(0, chase.roundCap - chase.round + 1) : null;
}

/**
 * Resolve the round once everyone has rolled: move the Lead, then either end the
 * chase or begin the next round (the ground is rolled again). 2026-10-21: after a
 * local chase's last round (the cap) the Lead decides it (capOutcome).
 * Returns { chase, move, outcome, capped }.
 */
export function resolveRound(chase) {
  if (!roundDone(chase)) throw new Error("not everyone has rolled this round");
  const move = roundMove(chase);
  const moved = applyLead(chase, move);
  const lead = moved.lead;
  const capped = !moved.outcome && !!capOutcome(chase, lead);
  const outcome = moved.outcome || capOutcome(chase, lead);
  const entry = {
    round: chase.round, face: chase.ground.face, key: chase.ground.key, mob: chase.mob,
    rolls: chase.members.map((m) => ({ actorId: m.actorId, name: m.name, ...chase.rolls[m.actorId] })),
    move, lead, ...(capped ? { capped: true } : {}),
  };
  const next = { ...chase, lead, history: [...chase.history, entry], outcome, ...(capped ? { capped: true } : {}) };
  // the next round rolls a new ground; the mob stays what it was set to when the chase started (D1)
  if (!outcome) Object.assign(next, { round: chase.round + 1, ground: null, rolls: {} });
  return { chase: next, move, outcome, capped };
}

/** The Storyteller moves the Lead by hand (a correction, or the chase run without automation). */
export function adjustLead(chase, delta) {
  if (!isRunning(chase)) throw new Error("the chase is over");
  const { lead, outcome } = applyLead(chase, Math.trunc(delta));
  return { ...chase, lead, outcome };
}

/** End the chase by hand, or because the hunt started during a local chase ("ended"). */
export function endChase(chase, outcome) {
  if (!DGF.chaseOutcomes.includes(outcome)) throw new Error(`unknown chase outcome: ${outcome}`);
  return { ...chase, outcome, lead: outcome === "escaped" ? chase.escape : outcome === "cornered" ? 0 : chase.lead };
}

/** Add a member (the Storyteller's correction); a member already in the chase is kept once. */
export function addMember(chase, member) {
  if (memberIn(chase, member.actorId)) return chase;
  return { ...chase, members: [...chase.members, { ...member }] };
}

/** Take a member out of the chase (the Storyteller's correction): its roll this round goes with it. */
export function removeMember(chase, actorId) {
  const rolls = { ...chase.rolls };
  delete rolls[actorId];
  return { ...chase, members: chase.members.filter((m) => m.actorId !== actorId), rolls };
}

/**
 * What being cornered does to each member still running. Local chase: captured (Already Dead: loses its next Turn
 * instead; V5: when the chase's rise brings the Limit, or the hunt ends the chase, Already Dead simply joins the final
 * flight: `atLimit`). Final flight: the party is forked.
 * Returns [{ actorId, name, fate: "captured" | "loseTurn" | "flees" | "forked" }].
 */
export function corneredFates(chase) {
  const ghostly = (m) => perkRule(m.perk).corneredLosesTurn;
  return chase.members.map((m) => ({
    actorId: m.actorId, name: m.name,
    fate: chase.kind === "final" ? "forked" : ghostly(m) ? (chase.atLimit ? "flees" : "loseTurn") : "captured",
  }));
}

/**
 * D1 + D2: who of a local chase that just ended stays behind when the hunt starts with it: anyone it captured
 * (cornered; Already Dead isn't, V5) and anyone who gave up in it. An escaped runner joins the flight.
 */
export function staysBehind(chase) {
  if (!chase || chase.kind !== "local") return [];
  const cornered = chase.outcome === "cornered" ? corneredFates({ ...chase, atLimit: true }).filter((f) => f.fate === "captured").map((f) => f.actorId) : [];
  return [...new Set([...cornered, ...(chase.gaveUp ?? []).map((g) => g.actorId)])];
}

/** F25: the hunt started (dawn, the Storyteller, or the Limit from elsewhere) during a local chase: it ends at once and they join the flight. */
export function limitEndsLocal(chase) {
  return isRunning(chase) && chase.kind === "local";
}

/**
 * F25 (and B3): the hunt started during a local chase. It ends at once and its Entities join the final flight — but
 * if its round was complete and corners them, they are captured first and stay behind (V5: Already Dead isn't captured
 * and loses no Turn: it simply joins the flight), and anyone who gave up stays behind. Returns { chase (the local
 * chase, ended or cornered, marked atLimit), staysBehind: [actorIds] }. The chase's rise so far is applied by the caller.
 */
export function endLocalAtLimit(chase) {
  if (!limitEndsLocal(chase)) return { chase, staysBehind: [] };
  const gave = (chase.gaveUp ?? []).map((g) => g.actorId);
  if (roundDone(chase)) {
    const out = resolveRound(chase);
    if (out.outcome === "cornered") {
      const cornered = { ...out.chase, atLimit: true };
      return { chase: cornered, staysBehind: staysBehind(cornered) };
    }
    if (out.outcome === "escaped") return { chase: { ...out.chase, atLimit: true }, staysBehind: gave };
    return { chase: { ...endChase(out.chase, "ended"), atLimit: true }, staysBehind: gave };
  }
  return { chase: { ...endChase(chase, "ended"), atLimit: true }, staysBehind: gave };
}
