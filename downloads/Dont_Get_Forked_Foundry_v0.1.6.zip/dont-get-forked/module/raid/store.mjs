/**
 * DON'T GET FORKED — the raid store (GM-authoritative)
 * ----------------------------------------------------
 * The raid's shared state (module/logic/raid.mjs) lives in the world setting
 * SETTINGS.raidState. Every client reads it; only the active GM writes it, one
 * write at a time (a promise queue), each write a pure function of the last
 * state. Players change it by asking the GM (runOp → the operations below).
 * When it changes, every client fires HOOKS.raidChanged (and suspicionChanged /
 * huntStarted, chaseChanged / chaseEnded) and refreshes its HUD and chase tracker.
 *
 * Slice 2 rides on every write: other parts register a `settle` (state → state,
 * run inside the write before the hunt is checked, e.g. a local chase that just
 * ended raising Suspicion once, D1, so its rise can bring the Limit), a `transform`
 * (state → state, run inside the write after it, e.g. the hunt starting the final
 * flight) and a `followUp` (run after the write is saved, e.g. rolling the ground,
 * capturing the cornered) with onRaidMutation() — see module/raid/chase-flow.mjs.
 */
import { SYSTEM_ID, SETTINGS, OPS, HOOKS, CARD, ACTOR_TYPES } from "../contracts.mjs";
import { DGF } from "../config.mjs";
import * as R from "../logic/raid.mjs";
import { registerOp, isActiveGM, runOp } from "../net/gm-ops.mjs";
import { setting } from "../settings.mjs";
import { cardOf, updateCard, postCard, setRaidIdReader, setEventAmountReader, postedByOwner } from "../chat/cards.mjs";
import { newRaidUpdate } from "../logic/lockup.mjs";
import { rollAbilities, isInRaid } from "../logic/entity.mjs";
import { assignExtraCharges } from "../logic/rules.mjs";
import { inLocalChase, isRunning, addOverdraw } from "../logic/chase.mjs";

/** The castle's upgrades (campaign play): the pieces brought home, three at most. */
export function castleUpgrades() {
  const v = game.settings.get(SYSTEM_ID, SETTINGS.castleUpgrades);
  return Array.isArray(v) ? v.map(String) : [];
}

/** The raid as every client sees it now. */
export function getRaid() {
  return R.normalizeRaid(game.settings.get(SYSTEM_ID, SETTINGS.raidState));
}

/** The current Suspicion, Limit, Turn … (for sheets, dialogs, macros). */
export function raidView() {
  return R.raidView(getRaid());
}

let queue = Promise.resolve();
const settlers = []; // (state, before) → state, inside each write, before the hunt is checked
const transforms = []; // (state, before) → state, inside each write
const followUps = []; // async (state, before), after each write is saved
const announcers = []; // async (before, state), inside each write, after the save

/** Register automation that rides on every raid write (see the header). */
export function onRaidMutation({ settle, transform, followUp, announce } = {}) {
  if (settle) settlers.push(settle);
  if (transform) transforms.push(transform);
  if (followUp) followUps.push(followUp);
  if (announce) announcers.push(announce);
}

/**
 * GM only: change the raid with a pure function (state → state, or { state, result }).
 * Starts the hunt when it is due (setting autoHunt) and announces what changed.
 */
export function mutateRaid(fn) {
  const job = queue.then(async () => {
    if (!isActiveGM()) throw new Error("only the active GM writes the raid");
    const before = getRaid();
    const out = fn(before);
    let state = out && out.state ? out.state : out;
    const result = out && out.state ? out.result : undefined;
    for (const st of settlers) state = st(state, before);
    let huntCause = "";
    if (setting(SETTINGS.autoHunt)) {
      huntCause = R.huntDue(state, before);
      if (huntCause) state = R.setHunt(state, true, huntCause);
    }
    for (const t of transforms) state = t(state, before);
    if (state === before) return { state, before, result, unchanged: true };
    await game.settings.set(SYSTEM_ID, SETTINGS.raidState, state);
    await announceChanges(before, state, huntCause);
    for (const a of announcers) await a(before, state);
    return { state, before, result };
  });
  queue = job.catch(() => {});
  job.then(({ state, before, unchanged }) => {
    if (unchanged) return;
    for (const f of followUps) Promise.resolve().then(() => f(state, before)).catch((err) => console.error("Don't Get Forked | raid follow-up failed", err));
  }, () => {});
  return job;
}

async function announce(event, state, extra = {}) {
  return postCard({ kind: CARD.raid, event, raidId: state.raidId, difficulty: state.difficulty, limit: state.limit, turns: state.turns, ...extra });
}

async function announceChanges(before, state, huntCause) {
  if (state.raidId !== before.raidId) return announce("newRaid", state);
  const atLimit = R.suspicionOf(state).atLimit, wasAtLimit = R.suspicionOf(before).atLimit;
  if (state.hunt && !before.hunt) await announce("hunt", state, { cause: state.huntCause || huntCause || "manual" });
  else if (state.dawn && !before.dawn) await announce("dawn", state);
  else if (atLimit && !wasAtLimit && !state.hunt) await announce("limit", state);
}

/* ------------------------------------------------- every client -- */

const lastSeen = new Map(); // user id → the state that client last saw (one entry in a real client)

/** Ready: remember the state this client starts from. */
export function primeRaid() {
  lastSeen.set(game.user?.id ?? "", getRaid());
}

/** The raid setting changed (runs on every client). */
export function onRaidChange(value, { refresh = () => {} } = {}) {
  const state = R.normalizeRaid(value);
  const key = game.user?.id ?? "";
  const prev = lastSeen.get(key) ?? R.normalizeRaid({});
  lastSeen.set(key, state);
  Hooks.callAll(HOOKS.raidChanged, state, prev);
  const now = R.suspicionOf(state).value, was = R.suspicionOf(prev).value;
  if (now !== was) Hooks.callAll(HOOKS.suspicionChanged, now, was);
  if (state.hunt && !prev.hunt) Hooks.callAll(HOOKS.huntStarted, state);
  if (JSON.stringify(state.chase) !== JSON.stringify(prev.chase)) {
    Hooks.callAll(HOOKS.chaseChanged, state.chase, prev.chase);
    const c = state.chase, p = prev.chase;
    if (p && p.id !== c?.id && !p.outcome) Hooks.callAll(HOOKS.chaseEnded, { ...p, outcome: "ended" }); // replaced while running (the Limit)
    if (c?.outcome && !(p && p.id === c.id && p.outcome)) Hooks.callAll(HOOKS.chaseEnded, c);
  }
  refresh(state, prev);
}

/* ------------------------------------------------- GM operations -- */

async function markCards(eventId, patch) {
  const ids = new Set(getRaid().ledger.filter((e) => e.eventId === eventId && e.messageId).map((e) => e.messageId));
  // a card about an event with no message of its own in the ledger (a local chase's one rise, D1)
  for (const m of game.messages.contents) if (cardOf(m)?.eventId === eventId) ids.add(m.id);
  for (const id of ids) {
    const m = game.messages.get(id);
    if (m && cardOf(m)) await updateCard(m, patch);
  }
}

const isEntity = (actor) => actor?.type === ACTOR_TYPES.entity;
const prefixed = (update) => Object.fromEntries(Object.entries(update).map(([k, v]) => [`system.${k}`, v]));
/** Every Entity in the world (one of the eight chosen), in this raid or not. */
const allEntities = () => game.actors.filter((a) => isEntity(a) && a.system.entityKey);

let dropping = Promise.resolve(); // one drop at a time (see dropFrom)

/**
 * V21: one of the Entity's loot items drops where it is (a Cost's "drop an item" or the owner's own drop, any time).
 * With autoDrops on it waits in the raid's dropped list until someone picks it up; off, or for an Entity that isn't
 * in this raid (F26: it isn't in town), it just leaves the sheet. Returns the item dropped, or null. GM only (it
 * writes the raid). Drops run one at a time, each reading the list the last one left, and `name` (when given) must
 * still be the item at `index`: a double click drops the item once, never a copy of it or the next one.
 */
function dropFrom(actor, index, { announce: say = true, name } = {}) {
  const job = dropping.then(async () => {
    const carried = [...(actor.system.carried ?? [])];
    if (!(index >= 0 && index < carried.length)) return null;
    if (typeof name === "string" && carried[index].name !== name) return null; // the list has changed since
    const [item] = carried.splice(index, 1);
    await actor.update({ "system.carried": carried });
    if (!setting(SETTINGS.autoDrops) || !isInRaid(actor.system)) return item;
    if (getRaid().hunt) {
      // V27: anything dropped in the final flight is left in town: nobody picks it up, so it isn't listed
      if (say) await announce("leftInTown", getRaid(), { names: [actor.name], label: item.name });
    } else {
      const { state } = await mutateRaid((s) => R.dropLoot(s, { id: foundry.utils.randomID(), name: item.name, by: actor.name }));
      if (say) await announce("drop", state, { names: [actor.name], label: item.name });
    }
    return item;
  });
  dropping = job.catch(() => {});
  return job;
}

/** May this user act for this Entity (its owner, or a Storyteller)? Checked from the request (v13 queries carry no sender). */
const actsFor = (user, actor) => !!user?.isGM || !!actor?.testUserPermission?.(user, "OWNER");

export function registerRaidOps() {
  // The Entity's owner (or the Storyteller): drop one of its loot items where it is, any time (V21).
  registerOp(OPS.raidDrop, {
    apply: async ({ actorId, index, name } = {}, { user }) => {
      const actor = game.actors.get(actorId);
      if (!isEntity(actor)) return { ok: false, reason: "notAnEntity" };
      if (!actsFor(user, actor)) return { ok: false, reason: "notYours" };
      // V24: not in a local chase (autoDrops; off, the table keeps this rule by hand)
      if (setting(SETTINGS.autoDrops) && inLocalChase(getRaid().chase, actor.id)) return { ok: false, reason: "inChase" };
      const item = await dropFrom(actor, Math.trunc(Number(index)), { name: typeof name === "string" ? name : undefined });
      return item ? { ok: true, item: item.name } : { ok: false, reason: "noItem" };
    },
  });

  // An Entity's owner (or the Storyteller): pick a dropped item up; it costs that Entity's next action (V21).
  registerOp(OPS.raidPickUp, {
    apply: async ({ dropId, actorId } = {}, { user }) => {
      if (!setting(SETTINGS.autoDrops)) return { ok: false, reason: "dropsOff" };
      const actor = game.actors.get(actorId);
      if (!isEntity(actor) || !isInRaid(actor.system)) return { ok: false, reason: "notAnEntity" };
      if (!actsFor(user, actor)) return { ok: false, reason: "notYours" };
      if (actor.system.status === "captured") return { ok: false, reason: "captured" };
      if (getRaid().hunt) return { ok: false, reason: "flight" }; // V27: nothing is picked up in the final flight
      if (getRaid().partyOut || getRaid().over) return { ok: false, reason: "outOfTown" }; // nobody is left in town to pick it up
      const { state, result } = await mutateRaid((s) => { const out = R.pickUpLoot(s, dropId); return { state: out.state, result: out.item }; });
      if (!result) return { ok: false, reason: "gone" };
      // V25: picking items up is the Entity's action for this Turn: one action for any number picked up in the Turn
      const names = actor.system.pickedUpTurn === state.turn && actor.system.pickedUp ? actor.system.pickedUp.split(", ") : [];
      if (!names.includes(result.name)) names.push(result.name);
      await actor.update({
        "system.carried": [...(actor.system.carried ?? []), { name: result.name }],
        "system.pickedUpTurn": state.turn,
        "system.pickedUp": names.join(", "),
      });
      await announce("pickUp", state, { names: [actor.name], label: result.name });
      return { ok: true, item: result.name };
    },
  });

  setRaidIdReader(() => getRaid().raidId);
  setEventAmountReader((eventId) => R.eventAmount(getRaid(), eventId));

  // Anyone: apply what a roll, ability, Tell or chase card raised. The amount comes from the card, never from the request:
  // its biggest trigger (`rise`), and D3 its overdraws on top (`overdrawRise`). A card from before D3 has only `suspicion`.
  registerOp(OPS.raidApplyCard, {
    apply: async ({ messageId }) => {
      const message = game.messages.get(messageId);
      const card = cardOf(message);
      if (!card || ![CARD.roll, CARD.ability, CARD.tell, CARD.chase].includes(card.kind)) return { ok: false, reason: "notACard" };
      if (!postedByOwner(message)) return { ok: false, reason: "notTheirs" }; // a card about someone else's Entity
      const raid = getRaid();
      if (card.raidId !== raid.raidId) return { ok: false, reason: "otherRaid" };
      if (card.cancelled) return { ok: false, reason: "cancelled" };
      // D1 + D3: an overdraw from the sheet in a local chase adds +2 to the chase's one rise, when it ends
      if (card.kind === CARD.ability && card.chaseOverdraws > 0) {
        const { result } = await mutateRaid((s) => {
          if (isRunning(s.chase) && s.chase.id === card.chaseId) return { state: R.setChase(s, addOverdraw(s.chase, { messageId, n: card.chaseOverdraws, actorId: card.actorId ?? "" })), result: "chase" };
          // the chase is over already (its rise is on the track): the overdraw raises Suspicion now, on its own
          return { state: R.recordEvent(s, { eventId: card.eventId, amount: 0, extra: card.chaseOverdraws * DGF.suspicion.overdraw, source: card.kind, label: "overdraw", actorName: card.actorName ?? "", messageId }), result: "now" };
        });
        if (!card.applied) await updateCard(message, { applied: true, ...(result === "now" ? { suspicion: card.chaseOverdraws * DGF.suspicion.overdraw, chaseId: "" } : {}) });
        return { ok: true, value: R.suspicionOf(getRaid()).value, to: result };
      }
      if (!(card.suspicion > 0)) return { ok: true, reason: "noop" };
      const rise = card.rise ?? card.suspicion;
      const { state } = await mutateRaid((s) => R.recordEvent(s, {
        eventId: card.eventId, amount: rise, extra: card.rise === undefined ? 0 : (card.overdrawRise ?? 0), source: card.kind,
        label: card.suspicionLabel ?? "", actorName: card.actorName ?? "", messageId: card.kind === CARD.chase ? "" : messageId,
        beforeHunt: card.kind === CARD.chase && !!card.riseBeforeHunt,
      }));
      if (!card.applied) await updateCard(message, { applied: true });
      return { ok: true, value: R.suspicionOf(state).value };
    },
  });

  // The Storyteller picks a Cost on a roll card (only one the rules allow there).
  registerOp(OPS.raidCost, {
    gmOnly: true,
    apply: async ({ messageId, choice, itemIndex = 0 }) => {
      const message = game.messages.get(messageId);
      const card = cardOf(message);
      if (card?.kind !== CARD.roll || card.band !== "cost") return { ok: false, reason: "notACost" };
      if (card.raidId !== getRaid().raidId) return { ok: false, reason: "otherRaid" }; // the last raid's card
      if (card.cost) return { ok: false, reason: "alreadyChosen" };
      if (!(card.costs ?? []).includes(choice)) return { ok: false, reason: "notAllowed" };
      // a group check's rolls rise once, by the biggest: a Suspicion +1 the group already raised costs nothing (T10)
      if (choice === "suspicion" && card.groupId && R.eventAmount(getRaid(), card.eventId) >= DGF.suspicion.cost) return { ok: false, reason: "costsNothing" };
      const actor = game.actors.get(card.actorId);
      const patch = { cost: choice };
      if (setting(SETTINGS.autoCosts)) {
        if (choice === "suspicion") {
          await mutateRaid((s) => R.recordEvent(s, { eventId: card.eventId, amount: DGF.suspicion.cost, source: "cost", label: "cost", actorName: card.actorName ?? "", messageId }));
          // the Cost is one of the roll's triggers (the biggest counts); an overdraw still adds on top (D3)
          const rise = Math.max(card.rise ?? card.suspicion ?? 0, DGF.suspicion.cost);
          const onTop = card.rise === undefined ? 0 : (card.overdrawRise ?? 0);
          Object.assign(patch, { rise, suspicion: rise + onTop, triggers: [...(card.triggers ?? []), { key: "cost", amount: DGF.suspicion.cost }], applied: true });
        } else if (choice === "smaller" && isEntity(actor)) {
          await actor.update({ "system.nextRollSmaller": (actor.system.nextRollSmaller ?? 0) + 1 });
        } else if (choice === "loseTurn" && isEntity(actor)) {
          const turn = getRaid().turn + 1;
          await actor.update({ "system.skipTurn": turn });
          patch.skipTurn = turn;
        } else if (choice === "drop" && isEntity(actor)) {
          const carried = actor.system.carried ?? [];
          const item = await dropFrom(actor, Math.min(Math.max(0, Number(itemIndex) || 0), carried.length - 1), { announce: false });
          patch.dropped = item?.name ?? "";
        }
      }
      await updateCard(message, patch);
      return { ok: true };
    },
  });

  registerOp(OPS.raidAdjust, {
    gmOnly: true,
    apply: async ({ delta, label = "" }) => {
      const n = Math.trunc(Number(delta));
      if (!n) return { ok: false, reason: "badDelta" };
      const { state } = await mutateRaid((s) => R.adjust(s, n, { label }));
      return { ok: true, value: R.suspicionOf(state).value };
    },
  });

  registerOp(OPS.raidCancel, {
    gmOnly: true,
    apply: async ({ eventId, restore = false }) => {
      if (!getRaid().ledger.some((e) => e.eventId === eventId)) return { ok: false, reason: "unknownEvent" };
      const { state } = await mutateRaid((s) => (restore ? R.restore(s, eventId) : R.cancel(s, eventId)));
      await markCards(eventId, { cancelled: !restore, applied: true });
      return { ok: true, value: R.suspicionOf(state).value };
    },
  });

  registerOp(OPS.raidUndo, {
    gmOnly: true,
    apply: async () => {
      const last = R.lastLiveEvent(getRaid());
      if (!last) return { ok: false, reason: "nothingToUndo" };
      const { state } = await mutateRaid((s) => R.cancel(s, last.eventId));
      await markCards(last.eventId, { cancelled: true, applied: true });
      return { ok: true, eventId: last.eventId, value: R.suspicionOf(state).value };
    },
  });

  // Next / previous Turn. B2 + V4: from the Turn the furniture's piece is taken until it leaves town or is
  // lost, each Turn's end raises Suspicion by 1, even while it is set down (autoFurniture).
  registerOp(OPS.raidTurn, {
    gmOnly: true,
    apply: async ({ delta = 1 }) => {
      const step = Math.sign(Number(delta)) || 1;
      const auto = setting(SETTINGS.autoFurniture);
      const carriers = game.actors.filter((a) => isEntity(a) && isInRaid(a.system) && a.system.carryingFurniture && a.system.status !== "captured").map((a) => a.name);
      const { state, before } = await mutateRaid((s) => (step > 0
        ? R.advanceTurn(auto ? R.endOfTurnFurniture(s, carriers) : s, 1)
        : R.advanceTurn(R.undoEndOfTurnFurniture(s), -1)));
      // V25: a pick-up was the Entity's action for its Turn: the mark goes when the Turn moves on
      if (step > 0 && (state.turn !== before.turn || state.dawn !== before.dawn)) {
        for (const a of game.actors.filter((x) => isEntity(x) && x.system.pickedUpTurn)) await a.update({ "system.pickedUpTurn": 0, "system.pickedUp": "" });
      }
      return { ok: true, turn: state.turn, dawn: state.dawn };
    },
  });

  // GM: the furniture's piece by hand — "inPlay" (taken), "out" (out of town), "lost" (the town took it back), "" (not taken).
  registerOp(OPS.raidFurniture, {
    gmOnly: true,
    apply: async ({ state: furniture }) => {
      if (!R.FURNITURE_STATES.includes(furniture)) return { ok: false, reason: "badState" };
      const { state } = await mutateRaid((s) => R.setFurniture(s, furniture));
      // lost or abandoned (V11): it stays put, so nobody carries it any more (as when a carrier is captured, F15)
      if (furniture === "lost") {
        for (const a of game.actors.filter((x) => isEntity(x) && x.system.carryingFurniture)) await a.update({ "system.carryingFurniture": false });
      }
      return { ok: true, furniture: state.furniture };
    },
  });

  // GM: take back a mistaken leaving of town (the way out, or the flight escaped), until the year is read. The party is
  // in town again; a piece that leaving took out of town or left behind is in play again. Nothing else changes.
  registerOp(OPS.raidBackInTown, {
    gmOnly: true,
    apply: async () => {
      const raid = getRaid();
      if (raid.over) return { ok: false, reason: "raidOver" };
      if (!raid.partyOut) return { ok: false, reason: "notOut" };
      const { state, before, unchanged } = await mutateRaid((s) => (s.over ? s : R.backInTown(s)));
      if (unchanged || state.partyOut) return { ok: false, reason: "notOut" };
      await announce("backInTown", state, { how: before.partyOut.how, pieceBack: state.furniture !== before.furniture });
      return { ok: true, furniture: state.furniture };
    },
  });

  // V4: the moment an Entity first takes the piece, it is in play (and noisy) until it leaves town or is lost.
  Hooks.on("updateActor", (actor, diff) => {
    if (!isActiveGM() || !isEntity(actor) || diff?.system?.carryingFurniture !== true || !setting(SETTINGS.autoFurniture)) return;
    if (!R.takesThePiece(getRaid(), { inRaid: isInRaid(actor.system) })) return; // F26: an Entity outside the raid isn't in town
    mutateRaid((s) => R.takeFurniture(s)).catch((err) => console.error("Don't Get Forked | furniture", err));
  });

  registerOp(OPS.raidHunt, {
    gmOnly: true,
    apply: async ({ on }) => {
      const { state } = await mutateRaid((s) => R.setHunt(s, !!on, "manual"));
      return { ok: true, hunt: state.hunt };
    },
  });

  registerOp(OPS.raidReset, {
    gmOnly: true,
    apply: async ({ difficulty = "standard", extra = {} }) => {
      if (!R.LABELS.includes(difficulty)) return { ok: false, reason: "badDifficulty" };
      // F26: who is in this raid: every Entity with a player owner (the Storyteller can change it on the Raid window
      // or the sheet). A new raid is a new year for them: free, charges refilled, the last raid's marks gone (resetOnNewRaid).
      const reset = setting(SETTINGS.resetOnNewRaid);
      const members = allEntities().filter((a) => a.hasPlayerOwner);
      // campaign play (Chapter 7): each castle upgrade gives one Entity of the players' choice one extra charge this raid
      const upgrades = setting(SETTINGS.campaign) ? castleUpgrades().length : 0;
      const given = assignExtraCharges({ wanted: extra, upgrades, members: members.map((a) => a.id) });
      if (!given.ok) return { ok: false, reason: given.reason };
      // 2026-10-21: the Limit by the party's size (five Entities: 1 lower on Easy and Standard; the switch limitByPartySize)
      const partySize = setting(SETTINGS.limitByPartySize) ? members.length : 0;
      const { state } = await mutateRaid(() => R.newRaid({ id: foundry.utils.randomID(), difficulty, readied: reset ? members.map((a) => a.id) : [], partySize }));
      for (const actor of allEntities()) {
        const inRaid = members.includes(actor);
        const plus = given.extra[actor.id] ?? 0;
        const update = { "system.inRaid": inRaid, "system.charges.extra": plus, "system.pickedUpTurn": 0, "system.pickedUp": "", ...(inRaid && reset ? prefixed(newRaidUpdate(actor.system)) : {}) };
        if (plus) update["system.charges.value"] = (inRaid && reset ? actor.system.charges.start : actor.system.charges.value) + plus;
        await actor.update(update);
      }
      const extras = Object.entries(given.extra).map(([id, n]) => ({ name: game.actors.get(id)?.name ?? "", n }));
      if (upgrades) await announce("castle", state, { upgrades: castleUpgrades(), extras });
      return { ok: true, raidId: state.raidId, members: members.map((a) => a.id), extra: given.extra };
    },
  });

  // GM (F26): tick an Entity into this raid or out of it (the Raid window; the sheet's tick does the same).
  registerOp(OPS.raidMember, {
    gmOnly: true,
    apply: async ({ actorId, inRaid }) => {
      const actor = game.actors.get(actorId);
      if (!isEntity(actor)) return { ok: false, reason: "notAnEntity" };
      await actor.update({ "system.inRaid": !!inRaid });
      await followPartySize();
      return { ok: true, inRaid: !!inRaid };
    },
  });

  // 2026-10-21: the sheet's tick changes who is in the raid too; the Limit follows the party's size (followPartySize)
  Hooks.on("updateActor", (actor, diff) => {
    if (!isActiveGM() || !isEntity(actor) || diff?.system?.inRaid === undefined) return;
    followPartySize().catch((err) => console.error("Don't Get Forked | the party's size", err));
  });

  // F26: an Entity ticked into the raid after it began is made ready for it once, as a new raid would have (resetOnNewRaid).
  Hooks.on("updateActor", (actor, diff) => {
    if (!isActiveGM() || !isEntity(actor) || diff?.system?.inRaid !== true || !setting(SETTINGS.resetOnNewRaid)) return;
    const raid = getRaid();
    if (!raid.raidId || R.markReadied(raid, actor.id) === raid) return;
    mutateRaid((s) => R.markReadied(s, actor.id))
      .then(() => actor.update(prefixed(newRaidUpdate(actor.system))))
      .catch((err) => console.error("Don't Get Forked | readying an Entity failed", err));
  });

  // Anyone: the helpers on a roll card pay for the abilities they lent (Chapter 3: helping costs the helper's charge),
  // once, as the card says. Read from a card its roller's owner posted, never from the request, so no player can
  // spend another Entity's charges (or bring its Weakness) at will.
  registerOp(OPS.actorSpendCharges, {
    apply: async ({ messageId } = {}) => {
      const message = game.messages.get(messageId);
      const card = cardOf(message);
      if (card?.kind !== CARD.roll) return { ok: false, reason: "notARoll" };
      if (!postedByOwner(message)) return { ok: false, reason: "notTheirs" };
      if (card.raidId !== getRaid().raidId) return { ok: false, reason: "otherRaid" }; // a new raid has refilled them
      if (card.helpersPaid !== false) return { ok: true, reason: "noop" };
      const paid = [];
      for (const p of (card.payments ?? []).filter((x) => !x.own && x.payerId !== card.actorId)) {
        const actor = game.actors.get(p.payerId);
        if (!isEntity(actor)) continue;
        const value = actor.system.charges?.value ?? 0;
        const most = rollAbilities(actor.system).length; // it can't lend more abilities than it has
        const spent = card.autoCharges && setting(SETTINGS.autoCharges) ? Math.min(value, most, Math.max(0, Math.trunc(Number(p.spend)) || 0)) : 0;
        const update = {};
        if (spent) update["system.charges.value"] = value - spent;
        // 2026-10-21: a flight overdraw costs its own step down from the payer's next roll (a card from before: the Weakness)
        if (p.step) update["system.overdrewInFlight"] = true; // once per flight (B3)
        else if (p.weakness) { update["system.weaknessInPlay"] = true; update["system.overdrewInFlight"] = true; }
        if (Object.keys(update).length) await actor.update(update);
        paid.push({ actorId: actor.id, spent, step: !!p.step });
      }
      await updateCard(message, { helpersPaid: true });
      return { ok: true, paid };
    },
  });
}

/**
 * 2026-10-21 (Chapters 5 and 8): the Limit follows the party's size (five Entities in the raid: 1 lower on Easy and
 * Standard) while the raid is in town and the hunt isn't on (module/logic/raid.mjs setPartySize). With the switch
 * limitByPartySize off the size isn't counted and the Limit is the label's. Active GM only.
 */
export async function followPartySize() {
  if (!isActiveGM()) return null;
  const raid = getRaid();
  if (!raid.raidId) return null;
  const n = setting(SETTINGS.limitByPartySize) ? allEntities().filter((a) => isInRaid(a.system)).length : 0;
  if (raid.partySize === n && raid.limit === R.setPartySize(raid, n).limit) return null;
  return mutateRaid((s) => R.setPartySize(s, n));
}

/* ------------------------------------------------- GM on ready -- */

/** GM, on ready: start a raid if the world has none yet. */
export async function seedRaid() {
  if (!isActiveGM() || getRaid().raidId) return;
  await mutateRaid(() => R.newRaid({ id: foundry.utils.randomID(), difficulty: "standard" }));
}

/**
 * GM, on ready: catch up on any roll this raid made while no Storyteller was connected: a helped roll's
 * helpers pay; a roll the raid follows goes through raid.roll; any other roll's Suspicion is applied (its
 * card has Suspicion, isn't applied or cancelled, and its event isn't in the ledger; with autoSuspicion on).
 */
export async function reconcile() {
  if (!isActiveGM()) return 0;
  const autoSuspicion = setting(SETTINGS.autoSuspicion);
  const raid = getRaid();
  if (!raid.raidId) return 0;
  const known = new Set(raid.ledger.map((e) => e.messageId).filter(Boolean));
  const recent = game.messages.contents.slice(-100);
  // a roll the raid follows (a group check, a chase round, a capture, the lock-up, the way out) that the GM never saw
  const tracked = (c) => c.kind === CARD.roll && (c.groupId || c.chaseId || c.lockup || c.caught || c.wayOutBeaten || (c.wayOut && !c.chase));
  const unseen = recent.filter((m) => { const c = cardOf(m); return c && tracked(c) && c.raidId === raid.raidId && !c.gmSeen; });
  // a roll the raid follows is reconciled whatever the switches (raid.roll reads them); its Suspicion only with autoSuspicion
  const todo = !autoSuspicion ? [] : recent.filter((m) => {
    const c = cardOf(m);
    return c && [CARD.roll, CARD.ability, CARD.tell].includes(c.kind) && c.raidId === raid.raidId && !unseen.includes(m)
      && (c.suspicion > 0 || (c.kind === CARD.ability && c.chaseOverdraws > 0)) && !c.hunt && !c.applied && !c.cancelled && !known.has(m.id);
  });
  // a helped roll whose helpers haven't paid yet (whatever the switches: the op reads them)
  const unpaid = recent.filter((m) => { const c = cardOf(m); return c?.kind === CARD.roll && c.raidId === raid.raidId && c.helpersPaid === false; });
  for (const m of unpaid) await runOp(OPS.actorSpendCharges, { messageId: m.id });
  for (const m of unseen) await runOp(OPS.raidRoll, { messageId: m.id });
  for (const m of todo) await runOp(OPS.raidApplyCard, { messageId: m.id });
  return todo.length + unseen.length + unpaid.length;
}
