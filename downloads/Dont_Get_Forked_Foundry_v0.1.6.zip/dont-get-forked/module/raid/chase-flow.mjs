/**
 * DON'T GET FORKED — chases and the lock-up at the table (GM-authoritative)
 * ------------------------------------------------------------------------
 * The Foundry side of module/logic/chase.mjs and lockup.mjs. Everything here
 * runs on the active Storyteller's (GM's) client, through the raid store's one
 * write queue; players reach it with GM operations (runOp).
 *
 *  - raid.roll: a roll card reached the GM — its Suspicion (when automatic), its
 *    place in an open group check, its round in the chase (D1: what it adds to the
 *    chase's one rise), a caught Entity's local chase, the lock-up (slipping free, a
 *    rescue: R1, the result first, so the freed join a flight its Suspicion starts)
 *    and the way out (R4: rolled once a Turn);
 *  - D1: a local chase's mob is set when it starts; when it ends (escaped, cornered,
 *    or everyone gave up) it raises Suspicion once, by the biggest trigger among all
 *    its rolls, plus +2 for each overdraw in it (D3). If that brings the Limit, the
 *    hunt starts once the chase is settled: an escaped runner joins the final flight;
 *    anyone cornered (Already Dead aside, V5) or who gave up was captured first;
 *  - the hunt starting starts the final flight (F25: a local chase still running ends,
 *    its rise so far goes on the track, and its Entities join the flight);
 *  - each round the ground is rolled, and once everyone still running has rolled the
 *    Lead moves (the majority rule for a shared Lead); escape or cornered ends the
 *    chase: cornered in a local chase is captured (the town takes back the loot;
 *    Already Dead loses its next Turn instead), in the final flight it is forked;
 *  - D2: at the start of a round a runner may give up (its owner or the Storyteller):
 *    captured, no roll; the others carry on;
 *  - D7b: everyone in the raid held at the lock-up at once ends the night: Forked
 *    (checked at each capture, and when the hunt or dawn would start);
 *  - 2026-10-21: a local chase lasts at most 6 rounds, then the Lead decides it (localRoundCap: the chase is made with
 *    its cap, module/logic/chase.mjs resolveRound ends it); a Huge piece with a carrier in a local chase can't move
 *    until the chase is over (hugePieceHeld: pieceHeldNow, read by the way out); either carrier captured, the town
 *    takes it (capture, F15);
 *  - the Storyteller's hand on the tracker: start, roll the ground, resolve the
 *    round, Lead ±1, end, add or take out a member, capture or free.
 * Every automation is switchable (autoChase, autoLockup, autoGroupChecks, autoYear, autoAllHeld, localRoundCap, hugePieceHeld).
 */
import { SETTINGS, OPS, CARD, ACTOR_TYPES } from "../contracts.mjs";
import { DGF } from "../config.mjs";
import * as R from "../logic/raid.mjs";
import * as C from "../logic/chase.mjs";
import { captureUpdate, freeUpdate, isCaptive, everyoneHeld } from "../logic/lockup.mjs";
import { groupRecord, groupDone, closeGroup, groupCaught, groupWithout } from "../logic/checks.mjs";
import { isInRaid } from "../logic/entity.mjs";
import { registerOp, isActiveGM, runOp } from "../net/gm-ops.mjs";
import { setting } from "../settings.mjs";
import { getRaid, mutateRaid, onRaidMutation } from "./store.mjs";
import { cardOf, updateCard, postCard, postedByOwner } from "../chat/cards.mjs";

const isEntity = (actor) => actor?.type === ACTOR_TYPES.entity;
const randomID = () => foundry.utils.randomID();
const prefix = (update) => Object.fromEntries(Object.entries(update).map(([k, v]) => [`system.${k}`, v]));

/** F26: is this Entity in the raid? (One without the mark, from an older world, is.) */
export function inRaid(actor) {
  return isInRaid(actor?.system);
}

/** Every Entity in the world (one of the eight chosen), in this raid or not. */
export function allEntities() {
  return game.actors.filter((a) => isEntity(a) && a.system.entityKey);
}

/** The Entities in this raid (F26): every raid rule (the flight, the checks, the lock-up, the year) counts only these. */
export function entities() {
  return allEntities().filter(inRaid);
}

/** A chase member from an Entity actor. */
export function memberFor(actor) {
  return C.memberOf({ id: actor.id, name: actor.name, system: actor.system });
}

/** Everyone who flees in the final flight: every Entity who isn't captured. */
export function partyForFlight() {
  return entities().filter((a) => !isCaptive(a.system)).map(memberFor);
}

/** Does anyone free carry the furniture's piece (so it leaves town with the party)? */
function pieceCarried() {
  return entities().some((a) => a.system.carryingFurniture && !isCaptive(a.system));
}

/**
 * 2026-10-21 (W4): is the Huge piece held by a local chase now: one of its carriers in the chase, the other outside it?
 * It stays with the other carrier and can't move (no way out) until the chase is over. Either carrier captured, the town
 * takes it (capture() below, F15).
 */
export function pieceHeldNow(raid = getRaid()) {
  const carriers = entities().filter((a) => a.system.carryingFurniture && !isCaptive(a.system)).map((a) => a.id);
  return C.holdsPiece(raid.chase, carriers);
}

/* ------------------------------------------------------------ starting -- */

/**
 * A local chase for these caught Entities (one, or several caught in one group check, on a shared Lead). D1: the mob's
 * Difficulty is set now, from the Suspicion as the chase starts.
 */
export function startLocal(state, actorIds, { groupId = "", where = "" } = {}) {
  if (state.over) return { state, started: false, reason: "raidOver" };
  if (state.partyOut) return { state, started: false, reason: "partyOut" };
  if (state.hunt) return { state, started: false, reason: "huntOn" };
  if (C.isRunning(state.chase)) return { state, started: false, reason: "chaseRunning" };
  const members = [...new Set(actorIds)].map((id) => game.actors.get(id)).filter((a) => isEntity(a) && inRaid(a)).map(memberFor);
  if (!members.length) return { state, started: false, reason: "nobody" };
  // 2026-10-21: at most 6 rounds (the switch localRoundCap; off, the chase runs until the Lead ends it)
  const roundCap = setting(SETTINGS.localRoundCap) ? DGF.localRoundCap.rounds : 0;
  const chase = C.newChase({ id: randomID(), kind: "local", cause: "caught", members, turn: state.turn, groupId, where, label: state.difficulty, suspicion: R.suspicionOf(state).value, roundCap });
  return { state: R.setChase(state, chase), started: true, chase };
}

/** Did this write just end the local chase (it was running before, and has its outcome now)? */
function justEndedLocal(state, before) {
  const c = state.chase, b = before?.chase;
  return !!c && c.kind === "local" && !!c.outcome && !!b && b.id === c.id && C.isRunning(b);
}

/** D1: the chase's one rise on the chase (its `endRise`, for the cards), applied to the track if Suspicion is automatic. */
function settleRise(state, chase, { beforeHunt = false } = {}) {
  const r = C.chaseRise(chase);
  const auto = r.total > 0 && setting(SETTINGS.autoSuspicion);
  const s = auto ? R.applyChaseRise(state, chase, { beforeHunt }) : state;
  return { state: s, chase: { ...chase, endRise: { ...r, applied: auto, beforeHunt } } };
}

/**
 * Inside every raid write, before the hunt is checked (D1, Chapter 6, One chase, one rise): a local chase that has just
 * ended — escaped, cornered, or everyone gave up — raises Suspicion once, by the biggest trigger among all its rolls,
 * plus +2 for each overdraw in it. Called off by the Storyteller ("dropped"), it raises nothing. Its rise can bring the
 * Limit: then the hunt starts in this same write, once the chase is settled (huntTransform → startFinal).
 */
function settleTransform(state, before) {
  if (!justEndedLocal(state, before) || !C.RISE_OUTCOMES.includes(state.chase.outcome) || state.chase.endRise) return state;
  const out = settleRise(state, state.chase);
  return R.setChase(out.state, out.chase);
}

/**
 * The final flight: everyone who isn't captured flees together.
 *  - D1: a local chase whose own rise just brought the Limit (it ended in this write): an escaped runner joins the
 *    flight; anyone it cornered (Already Dead aside, V5) or who gave up was captured first and stays behind.
 *  - F25: a local chase still running (dawn, the hunt by hand, or the Limit from elsewhere) ends at once, its rise so
 *    far goes on the track, and its Entities join the flight — except anyone a complete round cornered, or who gave up.
 * The capture itself is a follow-up (consequences()).
 */
export function startFinal(state, cause = "manual", before = null) {
  if (state.over) return { state, started: false, reason: "raidOver" };
  if (state.partyOut) return { state, started: false, reason: "partyOut" };
  if (C.isRunning(state.chase) && state.chase.kind === "final") return { state, started: false, reason: "chaseRunning" };
  let s = state;
  let behind = [];
  if (C.limitEndsLocal(s.chase)) {
    const out = C.endLocalAtLimit(s.chase);
    const settled = settleRise(s, out.chase, { beforeHunt: true });
    s = { ...R.setChase(settled.state, settled.chase), endedChase: settled.chase };
    behind = out.staysBehind;
  } else if (justEndedLocal(s, before)) {
    const ended = { ...s.chase, atLimit: true };
    s = { ...R.setChase(s, ended), endedChase: ended };
    behind = C.staysBehind(ended);
  }
  const members = partyForFlight().filter((m) => !behind.includes(m.actorId));
  if (!members.length) return { state: s, started: false, reason: "nobody" };
  const chase = C.newChase({ id: randomID(), kind: "final", cause, members, turn: s.turn, label: s.difficulty });
  return { state: R.setChase(s, chase), started: true, chase };
}

/**
 * Inside every raid write: when the whole town starts to hunt, a local chase ends
 * at once and everyone who isn't captured flees in the final flight; when the
 * Storyteller stops the hunt, the flight is called off.
 */
function huntTransform(state, before) {
  if (!setting(SETTINGS.autoChase)) return state;
  if (state.hunt && !before.hunt) return startFinal(state, state.huntCause || "manual", before).state;
  if (!state.hunt && before.hunt && C.isRunning(state.chase) && state.chase.kind === "final") return R.setChase(state, C.endChase(state.chase, "dropped"));
  return state;
}

/* -------------------------------------------------------- announcing -- */

function chaseFacts(chase, state, extra = {}) {
  return {
    v: 1, kind: CARD.chase, raidId: state.raidId, chaseId: chase.id, chaseKind: chase.kind, cause: chase.cause,
    round: chase.round, lead: chase.lead, start: chase.start, escape: chase.escape, mob: chase.mob,
    ground: chase.ground ? { ...chase.ground } : null, members: chase.members.map((m) => m.name), outcome: chase.outcome,
    gaveUp: (chase.gaveUp ?? []).map((g) => g.name), roundCap: chase.roundCap ?? 0, capped: !!chase.capped, ...extra,
  };
}

/** What being cornered or getting clear means, for the card; and (D1) the chase's one rise, on the card that ends it. */
function outcomeFacts(chase, state) {
  const out = chase.outcome === "cornered" ? { fates: C.corneredFates(chase).map((f) => ({ name: f.name, fate: f.fate })) } : {};
  return { ...out, ...riseFacts(chase, state) };
}

/**
 * D1: a local chase's one rise, as card facts (the card that ends the chase): with Suspicion automatic it is on the
 * track already; otherwise the Storyteller's Apply Suspicion puts it there (raid.applyCard reads these facts).
 */
function riseFacts(chase, state) {
  const r = chase.endRise;
  if (!r || chase.kind !== "local") return {};
  const names = [...(chase.members ?? []), ...(chase.gaveUp ?? [])].map((m) => m.name).filter(Boolean);
  return {
    riseShown: true, eventId: C.riseEventId(chase), suspicion: r.total, rise: r.rise, overdrawRise: r.overdrawRise, overdraws: r.overdraws,
    riseKeys: [...r.keys], suspicionLabel: [...r.keys, ...(r.overdraws ? ["overdraw"] : [])].join(","), actorName: [...new Set(names)].join(", "),
    applied: !!r.applied, cancelled: false, hunt: false, riseBeforeHunt: !!r.beforeHunt, turn: state.turn,
  };
}

/** A round's card facts from a chase's last history entry. */
function roundFacts(chase, state) {
  const h = chase.history.at(-1);
  return chaseFacts(chase, state, { event: "round", round: h.round, mob: h.mob, ground: C.groundOn(h.face), move: h.move, rolls: h.rolls.map((r) => ({ name: r.name, band: r.band, critical: r.critical })), ...outcomeFacts(chase, state) });
}

/** Inside every raid write, after the save: the chase cards (start, who gave up, each round's Lead, the end and its rise). */
async function announceChase(before, state) {
  if (state.raidId !== before.raidId) return; // a new raid: nothing to say about the last one's chase
  const c = state.chase, b = before.chase;
  const ended = state.endedChase && state.endedChase.id !== before.endedChase?.id ? state.endedChase : null;
  // D2: who gave up in this write, first
  const same = (x) => !!x && !!b && x.id === b.id;
  const now = same(ended) ? ended : same(c) ? c : null;
  for (const g of (now?.gaveUp ?? []).slice(b?.gaveUp?.length ?? 0)) await postCard(chaseFacts(now, state, { event: "gaveUp", names: [g.name], outcome: "" }));
  if (ended && b?.id === ended.id) {
    // the hunt followed (or ended) a local chase: its last round (if this write completed it), else its end
    if (ended.history.length > b.history.length) await postCard(roundFacts(ended, state));
    else await postCard(chaseFacts(ended, state, { event: "end", ...outcomeFacts(ended, state) }));
  } else if (b && C.isRunning(b) && (!c || c.id !== b.id)) await postCard(chaseFacts({ ...b, outcome: "ended" }, state, { event: "end" }));
  if (!c || c.id === ended?.id) return; // nobody left to flee: the ended chase is still the raid's, and was just announced
  if (!b || b.id !== c.id) {
    await postCard(chaseFacts(c, state, { event: "start" }));
    return;
  }
  if (c.history.length > b.history.length) {
    await postCard(roundFacts(c, state));
  } else if (c.outcome && !b.outcome) {
    await postCard(chaseFacts(c, state, { event: "end", ...outcomeFacts(c, state) }));
  }
}

/* ------------------------------------------------------- running it -- */

const pendingGround = new Set();

/**
 * Roll the ground for this chase's round (one d6 on the chase table, for everyone) and check the mob.
 * Once per round; `force` (the Storyteller's button) rolls it again while nobody has rolled yet.
 */
export async function rollGround({ id, round, force = false } = {}) {
  const now = getRaid().chase;
  if (!C.isRunning(now)) return { ok: false, reason: "noChase" };
  if (now.ground && !force) return { ok: false, reason: "groundRolled" };
  const key = `${id ?? now.id}:${round ?? now.round}`;
  if (pendingGround.has(key)) return { ok: false, reason: "pending" };
  pendingGround.add(key);
  try {
    const roll = await new Roll("1d6").evaluate();
    const { state, result } = await mutateRaid((s) => {
      const c = s.chase;
      if (!C.isRunning(c) || (id && c.id !== id) || (round && c.round !== round)) return { state: s, result: { ok: false, reason: "noChase" } };
      if (Object.keys(c.rolls).length) return { state: s, result: { ok: false, reason: "alreadyRolling" } };
      if (c.ground && !force) return { state: s, result: { ok: false, reason: "groundRolled" } };
      return { state: R.setChase(s, C.startRound(c, { face: roll.total, suspicion: R.suspicionOf(s).value, label: s.difficulty })), result: { ok: true } };
    });
    if (!result.ok) return result;
    const c = state.chase;
    const weak = c.members.filter((m) => C.weaknessFor(c, m.actorId, { marked: !!game.actors.get(m.actorId)?.system?.weaknessInPlay })).map((m) => m.name);
    await postCard(chaseFacts(c, state, { event: "ground", weak, extras: c.members.filter((m) => C.traitsFor(c, m.actorId).length > c.ground.traits.length).map((m) => ({ name: m.name, traits: C.traitsFor(c, m.actorId) })) }), { rolls: [roll] });
    return { ok: true, face: roll.total };
  } finally {
    pendingGround.delete(key);
  }
}

/** Move the Lead by the round's rolls (everyone has rolled). */
export async function resolveNow({ id, round } = {}) {
  const { result } = await mutateRaid((s) => {
    const c = s.chase;
    if (!C.isRunning(c) || (id && c.id !== id) || (round && c.round !== round)) return { state: s, result: { ok: false, reason: "noChase" } };
    if (!C.roundDone(c)) return { state: s, result: { ok: false, reason: "waiting" } };
    const out = C.resolveRound(c);
    return { state: R.setChase(s, out.chase), result: { ok: true, move: out.move, outcome: out.outcome } };
  });
  return result;
}

/** After a write: the next step of a chase the automation runs (roll the ground, or move the Lead). */
export async function driveChase() {
  if (!isActiveGM() || !setting(SETTINGS.autoChase)) return null;
  const c = getRaid().chase;
  if (!C.isRunning(c)) return null;
  if (!c.ground) return rollGround({ id: c.id, round: c.round });
  if (C.roundDone(c)) return resolveNow({ id: c.id, round: c.round });
  return null;
}

/**
 * Capture an Entity: held at the lock-up, and the town takes back what it carried. F15: a
 * carrier's furniture is lost for the night — nobody carries it any more and it can't come home.
 */
async function capture(actor, turn) {
  const c = captureUpdate(actor.system, { turn });
  await actor.update(prefix(c.update));
  if (c.furniture) {
    await mutateRaid((s) => R.loseFurniture(s));
    for (const other of entities().filter((a) => a.id !== actor.id && a.system.carryingFurniture)) await other.update({ "system.carryingFurniture": false });
  }
  return { name: actor.name, taken: c.taken, kept: c.kept, furniture: c.furniture };
}

/**
 * D7b (Chapter 6, Everyone held): if every Entity in the raid is held at the lock-up at once, the night ends there and
 * then, and the year is Forked (setting autoAllHeld). Checked at each capture, and when the hunt or dawn would start.
 * Returns true if it ended the night. Active Storyteller only.
 */
export async function checkAllHeld() {
  if (!isActiveGM() || !setting(SETTINGS.autoAllHeld)) return false;
  const raid = getRaid();
  if (!raid.raidId || raid.over || raid.partyOut || !everyoneHeld(entities())) return false;
  const { finishForked } = await import("./raid-checks.mjs");
  return !!(await finishForked({ cause: "allHeld" }));
}

/** What a chase's end does to the Entities and the raid (once, when its outcome is first known). */
async function consequences(chase, state) {
  if (chase.outcome === "cornered" && chase.kind === "local" && setting(SETTINGS.autoLockup)) {
    const fates = [];
    for (const f of C.corneredFates(chase)) {
      const actor = game.actors.get(f.actorId);
      if (!isEntity(actor)) continue;
      if (f.fate === "captured") fates.push({ ...(await capture(actor, state.turn)), fate: "captured" });
      else if (f.fate === "loseTurn") { await actor.update({ "system.skipTurn": state.turn + 1 }); fates.push({ name: actor.name, fate: "loseTurn", skipTurn: state.turn + 1 }); }
    }
    if (fates.length) await postCard(chaseFacts(chase, state, { event: "captured", fates }));
    if (fates.some((f) => f.fate === "captured")) await checkAllHeld(); // D7b
  }
  if (chase.kind === "final" && ["escaped", "cornered", "dropped"].includes(chase.outcome) && setting(SETTINGS.autoChase)) {
    // the Weakness an overdraw brought lasts to the end of the flight; so does the one overdraw it allows (B3)
    for (const m of chase.members) {
      const actor = game.actors.get(m.actorId);
      if (isEntity(actor) && (actor.system.weaknessInPlay || actor.system.overdrewInFlight)) await actor.update({ "system.weaknessInPlay": false, "system.overdrewInFlight": false });
    }
  }
  // out of town: a carried piece goes with the party, one set down stays put (V4); no hunt or chase starts any more
  if (chase.kind === "final" && chase.outcome === "escaped") {
    const carried = pieceCarried();
    await mutateRaid((s) => R.leaveTown(s, "flight", { carried }));
  }
  if (chase.kind === "final" && setting(SETTINGS.autoYear)) {
    const { finishForked, promptHome } = await import("./raid-checks.mjs");
    if (chase.outcome === "cornered") await finishForked();
    else if (chase.outcome === "escaped") await promptHome("flight");
  }
}

/** After every raid write: a newly ended chase's consequences, then the chase's next automatic step. */
async function chaseFollowUp(state, before) {
  const c = state.chase, b = before.chase;
  // B3: a local chase the Limit ended in a round that cornered them: they are captured first
  const ended = state.endedChase && state.endedChase.id !== before.endedChase?.id ? state.endedChase : null;
  if (ended?.outcome === "cornered") await consequences(ended, state);
  // nobody left to flee: the ended chase is still the raid's chase; its consequences came once, above
  if (c?.outcome && c.id !== ended?.id && !(b && b.id === c.id && b.outcome)) await consequences(c, state);
  // the whole town would hunt (or dawn comes), but everyone is held at the lock-up: D7b, the night ends, Forked;
  // with that switch off, nobody flees and the Storyteller is asked about the year (as before D7b)
  if (isActiveGM() && ((state.hunt && !before.hunt) || (state.dawn && !before.dawn)) && !getRaid().over) {
    if (await checkAllHeld()) return;
    if (state.hunt && !before.hunt && !setting(SETTINGS.autoAllHeld) && setting(SETTINGS.autoChase) && setting(SETTINGS.autoYear)
      && !(C.isRunning(c) && c.kind === "final") && !partyForFlight().length && entities().length) {
      const { promptHome } = await import("./raid-checks.mjs");
      await promptHome("nobody");
    }
  }
  await driveChase();
}

/* ------------------------------------------------------ GM operations -- */

async function markChaseStarted(messageIds, chaseId) {
  for (const id of messageIds) {
    const m = game.messages.get(id);
    if (m && cardOf(m) && !cardOf(m).chaseStarted) await updateCard(m, { chaseStarted: chaseId });
  }
}

/** The messages of a group check's caught rolls (this raid). */
function caughtInGroup(groupId, raidId) {
  return game.messages.contents.filter((m) => {
    const c = cardOf(m);
    return c?.kind === CARD.roll && c.raidId === raidId && c.groupId === groupId && c.caught;
  });
}

function warnGM(reason) {
  if (reason && game.user?.isGM) ui.notifications.warn(game.i18n.localize(`DGF.Chase.refused.${reason}`));
}

/** The lock-up after a slip or rescue roll (setting autoLockup): who is free now. */
async function lockupEffects(card, turn) {
  if (!setting(SETTINGS.autoLockup)) return [];
  const freed = [];
  if (card.lockup === "slip") {
    const actor = game.actors.get(card.actorId);
    if (isEntity(actor) && isCaptive(actor.system)) {
      await actor.update({ "system.slipTurn": turn, ...(card.freed ? prefix(freeUpdate()) : {}) });
      if (card.freed) freed.push(actor.name);
    }
  }
  if (card.rescued) {
    for (const actor of entities().filter((a) => isCaptive(a.system))) {
      await actor.update(prefix(freeUpdate()));
      freed.push(actor.name);
    }
  }
  return freed;
}

/**
 * A deleted Entity leaves the running chase (its round can then complete; with nobody left, the chase is off) and
 * the open group check (complete without it, the check closes and those caught flee together).
 */
async function dropDeleted(actorId) {
  const { state } = await mutateRaid((s) => {
    let st = s;
    if (C.isRunning(st.chase) && C.memberIn(st.chase, actorId)) {
      const c = C.removeMember(st.chase, actorId);
      st = R.setChase(st, c.members.length ? c : C.endChase(c, "dropped"));
    }
    if (st.group?.open && st.group.members.some((m) => m.actorId === actorId)) st = R.setGroup(st, groupWithout(st.group, actorId));
    return st;
  });
  if (state.group?.open && groupDone(state.group)) await runOp(OPS.raidGroup, { action: "close" });
}

export function registerChaseOps() {
  onRaidMutation({ settle: settleTransform, transform: huntTransform, announce: announceChase, followUp: chaseFollowUp });

  // Only the active Storyteller's client writes: a deleted Entity leaves the chase and the group check.
  Hooks.on("deleteActor", (actor) => {
    if (!isActiveGM() || !isEntity(actor)) return;
    dropDeleted(actor.id).catch((err) => console.error("Don't Get Forked | dropping a deleted Entity failed", err));
  });

  // A chase round's roll is recorded even if its roller's request is lost (they dropped mid-roll): the active
  // Storyteller's client picks the card up as it arrives. raid.roll is idempotent for a chase card (the same
  // message is recorded once, its Suspicion entry replaced), so the roller's own request then changes nothing.
  Hooks.on("createChatMessage", (message) => {
    if (!isActiveGM()) return;
    const card = cardOf(message);
    if (card?.kind !== CARD.roll || !card.chaseId || card.gmSeen || card.caught || card.lockup || card.wayOutBeaten || card.groupId) return;
    runOp(OPS.raidRoll, { messageId: message.id }).catch((err) => console.error("Don't Get Forked | chase roll pick-up failed", err));
  });

  // Anyone: a roll card reached the GM. Everything is read from the card, never from the request.
  registerOp(OPS.raidRoll, {
    apply: async ({ messageId }) => {
      const message = game.messages.get(messageId);
      const card = cardOf(message);
      if (card?.kind !== CARD.roll) return { ok: false, reason: "notARoll" };
      if (!postedByOwner(message)) return { ok: false, reason: "notTheirs" }; // a card about someone else's Entity
      const raid = getRaid();
      if (card.raidId !== raid.raidId) return { ok: false, reason: "otherRaid" };
      const autoSusp = setting(SETTINGS.autoSuspicion) && card.suspicion > 0 && !card.hunt && !card.cancelled;
      const autoChase = setting(SETTINGS.autoChase);
      const autoGroup = setting(SETTINGS.autoGroupChecks);
      const carried = card.wayOutBeaten && pieceCarried();
      // R1 (the result first): a slip or a rescue frees its captives before its Suspicion counts, so if that brings the
      // Limit, the freed flee in the final flight with everyone else (the flight starts inside the write below)
      const freed = card.gmSeen ? [] : await lockupEffects(card, raid.turn); // once per card (a replay frees nobody captured since)
      const { state, result } = await mutateRaid((s0) => {
        let s = s0;
        const res = { suspicion: false, chase: "", group: "", started: "" };
        if (autoSusp) {
          // the roll's biggest trigger, and D3 each overdraw on top (a card from before D3 has only `suspicion`)
          s = R.recordEvent(s, { eventId: card.eventId, amount: card.rise ?? card.suspicion, extra: card.rise === undefined ? 0 : (card.overdrawRise ?? 0), source: card.kind, label: card.suspicionLabel ?? "", actorName: card.actorName ?? "", messageId });
          res.suspicion = true;
        }
        // R4: the way out has been rolled this Turn (it can be rolled once a Turn)
        if (card.wayOut && !card.chase) s = R.markWayOut(s, card.turn ?? s.turn);
        // the way out beaten: the party is out of town (no hunt or chase starts, dawn included); a carried piece
        // goes with it, one set down stays put, abandoned (V4): no more furniture noise either way
        if (card.wayOutBeaten) s = R.leaveTown(s, "wayOut", { carried });
        // its round in the chase, and (D1) what it adds to the chase's one rise (a chase the hunt has ended no longer counts it)
        if (card.chaseId && s.chase?.id === card.chaseId) {
          const r = C.recordRoll(s.chase, card.actorId, { messageId, round: card.chaseRound, band: card.band, critical: card.critical, rise: card.chaseRise ?? 0, riseKeys: card.chaseRiseKeys ?? [], overdraws: card.chaseOverdraws ?? 0 });
          if (r.ok) s = R.setChase(s, r.chase);
          res.chase = r.reason ?? "recorded";
        }
        // its place in the group check; when everyone has rolled, those caught flee together
        let caughtIds = [];
        if (card.groupId && autoGroup && s.group?.id === card.groupId) {
          const g = groupRecord(s.group, card.actorId, { messageId, caught: card.caught });
          if (g.ok) {
            s = R.setGroup(s, g.group);
            if (groupDone(g.group)) {
              s = R.setGroup(s, closeGroup(g.group));
              res.group = "closed";
              caughtIds = groupCaught(g.group).map((m) => m.actorId);
            } else res.group = "recorded";
          } else res.group = g.reason;
        } else if (card.caught) caughtIds = [card.actorId];
        if (caughtIds.length && autoChase) {
          const st = startLocal(s, caughtIds, { groupId: card.groupId && res.group === "closed" ? card.groupId : "" });
          s = st.state;
          res.started = st.started ? st.chase.id : "";
          res.refused = st.reason ?? "";
        }
        return { state: s, result: res };
      });
      const patch = { gmSeen: true };
      if (result.suspicion && !card.applied) patch.applied = true;
      await updateCard(message, patch);
      if (result.started) {
        const ids = card.groupId && result.group === "closed" ? caughtInGroup(card.groupId, raid.raidId).map((m) => m.id) : [messageId];
        await markChaseStarted(ids, result.started);
      } else if (result.refused && result.refused !== "nobody") warnGM(result.refused);
      if (freed.length) await updateCard(message, { freedNames: freed });
      if (card.wayOutBeaten && setting(SETTINGS.autoYear) && !state.over) {
        const { promptHome } = await import("./raid-checks.mjs");
        await promptHome("wayOut");
      }
      return { ok: true, ...result, freed };
    },
  });

  // GM: a local chase from a caught card (its whole group check), or the final flight, by hand.
  registerOp(OPS.chaseStart, {
    gmOnly: true,
    apply: async ({ messageId = "", final = false } = {}) => {
      if (final) {
        const { result } = await mutateRaid((s) => {
          const st = startFinal(s, s.huntCause || "manual");
          return { state: st.state, result: st };
        });
        return result.started ? { ok: true, chaseId: result.chase.id } : { ok: false, reason: result.reason };
      }
      const message = game.messages.get(messageId);
      const card = cardOf(message);
      if (card?.kind !== CARD.roll || !card.caught) return { ok: false, reason: "notCaught" };
      const raid = getRaid();
      if (card.raidId !== raid.raidId) return { ok: false, reason: "otherRaid" };
      if (card.chaseStarted) return { ok: false, reason: "alreadyStarted" };
      const msgs = card.groupId ? caughtInGroup(card.groupId, raid.raidId) : [message];
      const ids = msgs.map((m) => cardOf(m).actorId);
      const { result } = await mutateRaid((s) => {
        let st = s;
        if (card.groupId && s.group?.id === card.groupId && s.group.open) st = R.setGroup(st, closeGroup(s.group));
        const out = startLocal(st, ids, { groupId: card.groupId ?? "" });
        return { state: out.started ? out.state : s, result: out };
      });
      if (!result.started) return { ok: false, reason: result.reason };
      await markChaseStarted(msgs.map((m) => m.id), result.chase.id);
      return { ok: true, chaseId: result.chase.id };
    },
  });

  registerOp(OPS.chaseGround, {
    gmOnly: true,
    apply: async () => {
      const c = getRaid().chase;
      if (!C.isRunning(c)) return { ok: false, reason: "noChase" };
      return rollGround({ id: c.id, round: c.round, force: true });
    },
  });

  registerOp(OPS.chaseResolve, {
    gmOnly: true,
    apply: async () => resolveNow({}),
  });

  registerOp(OPS.chaseLead, {
    gmOnly: true,
    apply: async ({ delta = 1 }) => {
      const n = Math.sign(Number(delta)) || 0;
      if (!n) return { ok: false, reason: "badDelta" };
      const { result } = await mutateRaid((s) => (C.isRunning(s.chase)
        ? { state: R.setChase(s, C.adjustLead(s.chase, n)), result: { ok: true } }
        : { state: s, result: { ok: false, reason: "noChase" } }));
      return { ...result, lead: getRaid().chase?.lead };
    },
  });

  registerOp(OPS.chaseEnd, {
    gmOnly: true,
    apply: async ({ outcome }) => {
      if (!["escaped", "cornered", "dropped"].includes(outcome)) return { ok: false, reason: "badOutcome" };
      const { result } = await mutateRaid((s) => (C.isRunning(s.chase)
        ? { state: R.setChase(s, C.endChase(s.chase, outcome)), result: { ok: true } }
        : { state: s, result: { ok: false, reason: "noChase" } }));
      return result;
    },
  });

  registerOp(OPS.chaseMember, {
    gmOnly: true,
    apply: async ({ actorId, remove = false }) => {
      const actor = game.actors.get(actorId);
      if (!remove && !isEntity(actor)) return { ok: false, reason: "notAnEntity" };
      const { result } = await mutateRaid((s) => {
        if (!C.isRunning(s.chase)) return { state: s, result: { ok: false, reason: "noChase" } };
        const next = remove ? C.removeMember(s.chase, actorId) : C.addMember(s.chase, memberFor(actor));
        return { state: R.setChase(s, next), result: { ok: true, members: next.members.length } };
      });
      return result;
    },
  });

  // D2 (Chapter 6, Giving up): at the start of a round (before anyone has rolled in it) a runner may give up: captured,
  // no roll; the others carry on (the majority rule counts only those still running). Its owner or the Storyteller.
  registerOp(OPS.chaseGiveUp, {
    apply: async ({ actorId } = {}, { user }) => {
      const actor = game.actors.get(actorId);
      if (!isEntity(actor)) return { ok: false, reason: "notAnEntity" };
      if (!(user?.isGM || actor.testUserPermission?.(user, "OWNER"))) return { ok: false, reason: "notYours" };
      const { state, result } = await mutateRaid((s) => {
        const out = C.giveUp(s.chase, actorId);
        return out.ok ? { state: R.setChase(s, out.chase), result: { ok: true } } : { state: s, result: { ok: false, reason: out.reason } };
      });
      if (!result.ok) return result;
      // captured, as if cornered: the town takes back what it carried (the lock-up by hand: the Storyteller does it)
      if (setting(SETTINGS.autoLockup)) {
        const facts = await capture(actor, state.turn);
        const where = [state.chase, state.endedChase].find((x) => x?.gaveUp?.some((g) => g.actorId === actorId)) ?? state.chase;
        await postCard(chaseFacts(where, state, { event: "captured", outcome: "", fates: [{ ...facts, fate: "captured" }] }));
        await checkAllHeld(); // D7b
      }
      return { ok: true, outcome: getRaid().chase?.outcome ?? "" };
    },
  });

  // GM: capture (the rules' way: the town takes back the loot) or free an Entity by hand.
  registerOp(OPS.lockupSet, {
    gmOnly: true,
    apply: async ({ actorId, captured }) => {
      const actor = game.actors.get(actorId);
      if (!isEntity(actor)) return { ok: false, reason: "notAnEntity" };
      if (captured) {
        const facts = await capture(actor, getRaid().turn);
        await checkAllHeld(); // D7b
        return { ok: true, ...facts };
      }
      await actor.update(prefix(freeUpdate()));
      return { ok: true };
    },
  });
}

/** The chase as the roll dialog needs it: this actor's context, or null when it isn't in a chase. */
export function chaseRollContext(actor, raid = getRaid()) {
  const c = raid.chase;
  if (!C.isRunning(c) || !C.memberIn(c, actor.id)) return null;
  return C.rollContext(c, actor.id, { marked: !!actor.system.weaknessInPlay });
}

/** The lock-up's Difficulty for this raid (the label's). */
export function lockupDifficulty(raid = getRaid()) {
  return DGF.labels[raid.difficulty]?.lockup ?? DGF.difficulty.hard;
}
