/**
 * DON'T GET FORKED — The raid's shared state (pure, Foundry-free)
 * ---------------------------------------------------------------
 * One raid's table state, kept in a world setting and written only by the
 * Storyteller's (GM's) client: the Suspicion ledger (module/logic/suspicion.mjs),
 * the Limit set by the town's difficulty, the Turn count and dawn, and whether
 * the whole town hunts. Every function returns a new state; nothing is mutated.
 *
 *   state = { v, raidId, difficulty, partySize, limit, turn, turns, dawn, hunt, huntCause,
 *             ledger: [{ id, eventId, amount, extra, source, label, actorName, messageId,
 *                        turn, cancelled, hunt }], seq,   // extra: D3, an overdraw's +2 on top of its event
 *             chase,   // the chase running (or the last one), module/logic/chase.mjs; null
 *             group,   // the group check open (or the last one), module/logic/checks.mjs; null
 *             tells,   // the Tell checks made: [{ id, place, turn, goesOff, actorId, name }]
 *             list,    // the shopping list: [{ name, duty, essential }]
 *             over,    // how the raid ended: null, or { result, turn } once the year is decided
 *             furniture, // V4: the piece: "" (not taken) | "inPlay" (taken, in town: noisy) | "out" (out of town) | "lost"
 *             furnitureTakenTurn, // V26: the Turn the piece was first taken (0: not yet, or an older raid)
 *             furnitureLost, // F15: a carrier was captured: the piece is gone for the night (furniture === "lost")
 *             dropped,  // V21: loot dropped where it fell, waiting to be picked up: [{ id, name, by, turn }]
 *             readied,  // F26: the Entities a new raid (or the Storyteller's tick) made ready for this raid; null in an older raid
 *             partyOut, // null, or { how: "wayOut" | "flight", turn, piece } once the party has left town (no hunt or chase starts);
 *                       //   piece: what that leaving made of the furniture ("out" | "lost"), or "" if it moved nothing
 *             wayOutTurn, // R4: the Turn the way out was last rolled (0: not yet): once a Turn
 *             endedChase } // the local chase the hunt ended or followed (D1: its rise brought the Limit; F25: dawn or the hunt by hand)
 *   partySize: the Entities in the raid (0: not counted, an older raid); the Limit is the label's, 1 lower on Easy and
 *              Standard with five Entities (2026-10-21, rules.mjs suspicionLimit; the switch limitByPartySize)
 *
 * Source: rulebook Chapter 4 (Turns: the night lasts 12 Turns; dawn comes when the
 * 12th Turn ends), Chapter 5 (the Limit by difficulty; one roll, one rise; at the
 * Limit, or at dawn, the whole town hunts; from then on Suspicion stops; the track
 * never goes past the Limit), Chapter 6 (chases, the lock-up) and Chapter 7 (the year).
 */
import { DGF } from "../config.mjs";
import { foldSuspicion, addEntry, cancelEvent, restoreEvent } from "./suspicion.mjs";
import { suspicionLimit } from "./rules.mjs";
import { chaseRise, riseEventId } from "./chase.mjs";

export const RAID_VERSION = 2;
/** V4: the furniture's piece in this raid. */
export const FURNITURE_STATES = Object.freeze(["", "inPlay", "out", "lost"]);
export const LABELS = Object.freeze(Object.keys(DGF.labels));

/**
 * A fresh raid at this difficulty ("easy" | "standard" | "hard"). `partySize`: the Entities in it (2026-10-21: with five
 * the Limit is 1 lower on Easy and Standard; 0 leaves the label's Limit).
 */
export function newRaid({ id = "", difficulty = "standard", readied = [], partySize = 0 } = {}) {
  if (!DGF.labels[difficulty]) throw new Error(`unknown difficulty: ${difficulty}`);
  const size = Math.max(0, Math.trunc(Number(partySize)) || 0);
  return {
    v: RAID_VERSION,
    raidId: id,
    difficulty,
    partySize: size,
    limit: suspicionLimit(difficulty, size),
    limitByHand: false, // 2026-10-29: the Storyteller set the Limit on the Raid window
    turn: 1,
    turns: DGF.turns,
    dawn: false,
    hunt: false,
    huntCause: "",
    ledger: [],
    seq: 0,
    chase: null,
    group: null,
    tells: [],
    list: [],
    over: null,
    furniture: "",
    furnitureLost: false,
    furnitureTakenTurn: 0,
    dropped: [],
    readied: [...readied],
    partyOut: null,
    wayOutTurn: 0,
    endedChase: null,
  };
}

/** Any stored value (possibly empty or from an older version) as a complete state. */
export function normalizeRaid(stored) {
  const s = stored && typeof stored === "object" ? stored : {};
  const difficulty = DGF.labels[s.difficulty] ? s.difficulty : "standard";
  const base = newRaid({ id: typeof s.raidId === "string" ? s.raidId : "", difficulty });
  const num = (v, d) => (Number.isFinite(v) ? v : d);
  return {
    ...base,
    partySize: Math.max(0, Math.trunc(num(s.partySize, 0))),
    limit: num(s.limit, base.limit),
    limitByHand: !!s.limitByHand,
    turn: Math.max(1, num(s.turn, base.turn)),
    turns: num(s.turns, base.turns),
    dawn: !!s.dawn,
    hunt: !!s.hunt,
    huntCause: typeof s.huntCause === "string" ? s.huntCause : "",
    ledger: Array.isArray(s.ledger) ? s.ledger.map((e) => ({ cancelled: false, hunt: false, ...e })) : [],
    seq: num(s.seq, 0),
    chase: s.chase && typeof s.chase === "object" && Array.isArray(s.chase.members) ? s.chase : null,
    group: s.group && typeof s.group === "object" && Array.isArray(s.group.members) ? s.group : null,
    tells: Array.isArray(s.tells) ? s.tells : [],
    list: Array.isArray(s.list) ? s.list : [],
    over: s.over && typeof s.over === "object" ? s.over : null,
    furniture: FURNITURE_STATES.includes(s.furniture) ? s.furniture : s.furnitureLost ? "lost" : "",
    furnitureTakenTurn: num(s.furnitureTakenTurn, 0), // an older raid: missing = not this Turn
    furnitureLost: s.furniture === "lost" || (!FURNITURE_STATES.includes(s.furniture) && !!s.furnitureLost),
    readied: Array.isArray(s.readied) ? s.readied : null, // an older raid didn't keep it: nobody is made ready again
    dropped: Array.isArray(s.dropped) ? s.dropped : [],
    partyOut: s.partyOut && typeof s.partyOut === "object" ? s.partyOut : null,
    wayOutTurn: num(s.wayOutTurn, 0),
    endedChase: s.endedChase && typeof s.endedChase === "object" && Array.isArray(s.endedChase.members) ? s.endedChase : null,
  };
}

/** The current Suspicion (the ledger folded against the Limit). */
export function suspicionOf(state) {
  return foldSuspicion(state.ledger, state.limit);
}

/** The ledger's events, newest first: one row per eventId, with its applied amount (the biggest trigger, plus every overdraw on top, D3). */
export function eventsOf(state) {
  const rows = new Map();
  for (const e of state.ledger) {
    const r = rows.get(e.eventId);
    if (!r) rows.set(e.eventId, { ...e, top: e.amount, extra: e.extra ?? 0, sources: [e.source], lastSeq: e.seq ?? 0 });
    else {
      if (e.amount > r.top) Object.assign(r, { top: e.amount, label: e.label || r.label });
      r.extra += e.extra ?? 0;
      r.sources.push(e.source);
      r.lastSeq = Math.max(r.lastSeq, e.seq ?? 0);
      r.cancelled = r.cancelled && e.cancelled;
    }
  }
  for (const r of rows.values()) r.amount = r.top + r.extra;
  return [...rows.values()].sort((a, b) => b.lastSeq - a.lastSeq);
}

/** Everything the HUD shows. */
export function raidView(state) {
  const s = suspicionOf(state);
  return {
    raidId: state.raidId,
    difficulty: state.difficulty,
    value: s.value,
    limit: state.limit,
    partySize: state.partySize ?? 0,
    limitByHand: !!state.limitByHand,
    bookLimit: suspicionLimit(state.difficulty, state.partySize ?? 0),
    labelLimit: DGF.labels[state.difficulty]?.limit ?? state.limit, // the label's own Limit (the difference: five Entities, 2026-10-21)
    atLimit: s.atLimit,
    turn: state.turn,
    turns: state.turns,
    dawn: state.dawn,
    hunt: state.hunt,
    huntCause: state.huntCause,
    exit: DGF.labels[state.difficulty]?.exit ?? null,
    lockup: DGF.labels[state.difficulty]?.lockup ?? null,
    over: state.over ? { ...state.over } : null,
    furniture: state.furniture ?? "",
    furnitureLost: !!state.furnitureLost,
    partyOut: state.partyOut ? { ...state.partyOut } : null,
  };
}

/**
 * Record (part of) an event. Entries sharing an eventId apply only their largest
 * amount (one roll, one rise; a group check's rolls share one event, so it rises
 * once, by the worst), and each entry's `extra` on top (D3: an overdraw's +2); the
 * same eventId + source + message again replaces that entry, so a retried request
 * never counts twice. While the hunt is on the entry is kept but ignored (Suspicion
 * stops) — unless `beforeHunt` (F25: a local chase's rise so far, applied as the hunt ends it).
 */
export function recordEvent(state, { eventId, amount, extra = 0, source, label = "", actorName = "", messageId = "", beforeHunt = false }) {
  if (!eventId) throw new Error("an event needs an eventId");
  if (!Number.isFinite(amount)) throw new Error(`event ${eventId}: amount must be a number`);
  if (!(Number.isFinite(extra) && extra >= 0)) throw new Error(`event ${eventId}: extra must be a number, 0 or more`);
  const seq = state.seq + 1;
  const id = messageId ? `${eventId}:${source}:${messageId}` : `${eventId}:${source}`;
  const entry = { id, eventId, amount, extra, source, label, actorName, messageId, turn: state.turn, seq, cancelled: false, hunt: beforeHunt ? false : state.hunt };
  const i = state.ledger.findIndex((e) => e.eventId === eventId && e.source === source && (e.messageId ?? "") === messageId);
  let ledger;
  if (i >= 0) {
    ledger = state.ledger.slice();
    ledger[i] = { ...entry, cancelled: state.ledger[i].cancelled, hunt: state.ledger[i].hunt, turn: state.ledger[i].turn };
  } else ledger = addEntry(state.ledger, entry);
  foldSuspicion(ledger, state.limit); // throws on an entry the rules don't allow (a lowering from a roll)
  return { ...state, ledger, seq };
}

/** Undo an event (every entry with this eventId stops counting). */
export function cancel(state, eventId) {
  return { ...state, ledger: cancelEvent(state.ledger, eventId) };
}

/** Count a cancelled event again. */
export function restore(state, eventId) {
  return { ...state, ledger: restoreEvent(state.ledger, eventId) };
}

/** The newest event that still counts, or null. */
export function lastLiveEvent(state) {
  return eventsOf(state).find((e) => !e.cancelled && !e.hunt) ?? null;
}

/** The Storyteller's +1 / −1 on the HUD: an event of its own. */
export function adjust(state, delta, { eventId, label = "" } = {}) {
  if (!Number.isInteger(delta) || delta === 0) throw new Error("adjust by a whole number of points");
  return recordEvent(state, { eventId: eventId ?? `st:${state.seq + 1}`, amount: delta, source: "storyteller", label });
}

/**
 * Move the Turn count. Forward past the last Turn is dawn ("dawn comes when the
 * 12th Turn ends"); back from dawn undoes it.
 */
export function advanceTurn(state, delta = 1) {
  if (delta > 0) {
    if (state.dawn) return state;
    if (state.turn >= state.turns) return { ...state, dawn: true };
    return { ...state, turn: Math.min(state.turns, state.turn + delta) };
  }
  if (delta < 0) {
    if (state.dawn) return { ...state, dawn: false };
    return { ...state, turn: Math.max(1, state.turn + delta) };
  }
  return state;
}

/**
 * 2026-10-21 (Chapters 5 and 8): the Entities in the raid changed (the Storyteller ticked one in or out): the Limit follows
 * the party's size (five: 1 lower on Easy and Standard) while the raid is still in town and the hunt isn't on; once it is
 * (or the raid is over) only the count changes. `size` 0 leaves the label's Limit.
 */
export function setPartySize(state, size) {
  const n = Math.max(0, Math.trunc(Number(size)) || 0);
  if (state.hunt || state.over || state.partyOut || state.limitByHand) return state.partySize === n ? state : { ...state, partySize: n };
  const limit = suspicionLimit(state.difficulty, n);
  return state.partySize === n && state.limit === limit ? state : { ...state, partySize: n, limit };
}

/** 2026-10-29 (Chapters 2 and 8): on Standard and Hard each Entity keeps its default Castle Duty; only Easy switches. */
export function dutiesLocked(state) {
  return state?.difficulty === "standard" || state?.difficulty === "hard";
}

/** 2026-10-29: the Storyteller sets the Limit by hand (1–30); the party's size no longer moves it this raid. */
export function setLimit(state, limit) {
  const n = Math.trunc(Number(limit));
  if (!(n >= 1 && n <= 30)) throw new Error(`bad Limit: ${limit}`);
  return state.limit === n && state.limitByHand ? state : { ...state, limit: n, limitByHand: true };
}

/** Start or stop the hunt by hand ("manual"), or as the rules say ("limit" / "dawn"). */
export function setHunt(state, on, cause = "manual") {
  return { ...state, hunt: !!on, huntCause: on ? cause : "" };
}

/**
 * Chapter 5: when Suspicion reaches the Limit, or dawn comes, the whole town hunts.
 * Returns the cause ("limit" | "dawn") if the hunt should start now, else "".
 * Given the state `before` a change, only the moment of reaching the Limit or of
 * dawn counts, so a Storyteller who stops the hunt by hand isn't overruled.
 */
export function huntDue(state, before = null) {
  if (state.hunt || state.over || state.partyOut) return ""; // dawn hunts only those still in town
  if (suspicionOf(state).atLimit && !(before && suspicionOf(before).atLimit)) return "limit";
  if (state.dawn && !(before && before.dawn)) return "dawn";
  return "";
}

/**
 * The rise an event's triggers make now (its biggest live entry), or 0: what decides whether a Cost's Suspicion +1
 * would add anything (an overdraw's +2 on top, D3, doesn't count here).
 */
export function eventAmount(state, eventId) {
  let best = 0;
  for (const e of state.ledger) if (e.eventId === eventId && !e.cancelled && !e.hunt && e.amount > best) best = e.amount;
  return best;
}

/**
 * D1 (Chapter 6, One chase, one rise): a local chase is over: it raises Suspicion once, by the biggest trigger among
 * all its rolls, plus +2 for each overdraw made in it (D3) — one event, its own (so a retry never counts twice).
 * `beforeHunt` (F25): the hunt ended the chase; its rise so far still goes on the track.
 */
export function applyChaseRise(state, chase, { beforeHunt = false } = {}) {
  const r = chaseRise(chase);
  if (!(r.total > 0)) return state;
  const names = [...(chase.members ?? []), ...(chase.gaveUp ?? [])].map((m) => m.name).filter(Boolean);
  return recordEvent(state, {
    eventId: riseEventId(chase), amount: r.rise, extra: r.overdrawRise, source: "chase",
    label: [...r.keys, ...(r.overdraws ? ["overdraw"] : [])].join(","), actorName: [...new Set(names)].join(", "), beforeHunt,
  });
}

/** R4 (Chapter 4, Getting Out): the way out has been rolled this Turn (it can be rolled once a Turn). */
export function markWayOut(state, turn = state.turn) {
  return state.wayOutTurn === turn ? state : { ...state, wayOutTurn: turn };
}

/** R4: has the way out already been rolled this Turn? */
export function wayOutRolled(state) {
  return !!state?.wayOutTurn && state.wayOutTurn === state.turn && !state.dawn;
}

/** The raid with this chase (module/logic/chase.mjs) as its current one (null: none). */
export function setChase(state, chase) {
  return { ...state, chase: chase ?? null };
}

/** The raid with this group check (module/logic/checks.mjs) as its current one (null: none). */
export function setGroup(state, group) {
  return { ...state, group: group ?? null };
}

/** Record a Tell check (for "once per watched location"). */
export function addTell(state, tell) {
  return { ...state, tells: [...state.tells, { ...tell, turn: state.turn }] };
}

/** The raid's shopping list (Chapter 4): [{ name, duty, essential }]. */
export function setList(state, list) {
  return { ...state, list: (list ?? []).map((it) => ({ name: String(it.name ?? ""), duty: it.duty, essential: !!it.essential })) };
}

/** The raid is over: the year is decided (no more hunts or chases start). */
export function endRaid(state, { result }) {
  return { ...state, over: { result, turn: state.turn }, chase: state.chase && !state.chase.outcome ? { ...state.chase, outcome: "dropped" } : state.chase, group: state.group ? { ...state.group, open: false } : null };
}

/** The Suspicion event for carried furniture at the end of a Turn (B2: its own event each Turn). */
export function furnitureEventId(turn) {
  return `furniture:${turn}`;
}

/**
 * B2 + V4 (Chapter 4, Carrying): from the Turn the piece is first taken until it leaves town
 * or the town takes it back, Suspicion rises by 1 at the end of each Turn — even while it is
 * set down. Call with the state before the Turn moves on and the names of anyone carrying it
 * now (carrying it marks it taken); a Turn ended again (after the Storyteller stepped back)
 * counts its event again, never twice.
 */
export function endOfTurnFurniture(state, carriers = []) {
  if (state.dawn || state.over || state.partyOut) return state;
  let s = carriers.length ? takeFurniture(state) : state;
  if (s.furniture !== "inPlay") return s;
  const eventId = furnitureEventId(s.turn);
  if (s.ledger.some((e) => e.eventId === eventId)) return restore(s, eventId);
  // set down, nobody's name goes with it: the event says so ("the furniture (set down)")
  return recordEvent(s, { eventId, amount: DGF.suspicion.furniture, source: "furniture", label: carriers.length ? "furniture" : "furnitureDown", actorName: carriers.join(", ") });
}

/**
 * V21 (Chapter 3, Cost): "A dropped item (drop yours any time) falls where you are; picking it up costs your next
 * action." The item waits in the raid's state (the system doesn't track places: `by` says who dropped it, so the
 * table knows where). A Cost's "drop an item" goes the same way.
 */
export function dropLoot(state, { id, name, by = "" }) {
  if (!id) throw new Error("a dropped item needs an id");
  return { ...state, dropped: [...(state.dropped ?? []), { id, name: String(name ?? ""), by: String(by ?? ""), turn: state.turn }] };
}

/**
 * V26 (Chapter 4): "Taking a piece is free (taking it back up is an action)". Given the raid, is taking the piece now
 * a retake: it is in play, and either this isn't the Turn it was first taken, or it is but nobody carries it now
 * (`setDown`: it was set down since, so this takes it back up)? So each carrier of a Huge piece taking it back up
 * spends an action, and so does a carrier who sets it down and takes it up again in the Turn of the first take, while
 * a second carrier joining the first take that Turn is free. An older raid without the first take's Turn counts as
 * "not this Turn".
 */
export function isFurnitureRetake(state, { setDown = false } = {}) {
  return state?.furniture === "inPlay" && (setDown || (state.furnitureTakenTurn ?? 0) !== state.turn);
}

/**
 * A Turn's mark on an Entity (a lost Turn, a pick-up) speaks to that Turn's own actions: its raid rolls. A chase
 * roll isn't one of them, nor is any roll once the hunt is on (everyone flees), nor at dawn. Does the mark made for
 * Turn `markTurn` apply to a roll now?
 */
export function turnMarkApplies(state, markTurn, { chaseRoll = false } = {}) {
  return !!markTurn && markTurn === state?.turn && !state.dawn && !state.hunt && !chaseRoll;
}

/** F26 + V4: does an Entity ticking "Carrying furniture" take the raid's piece for the first time? Only one in the raid. */
export function takesThePiece(state, { inRaid = true } = {}) {
  return !!inRaid && state?.furniture === "";
}

/** V21: someone picks a dropped item up. Returns { state, item } (item null if it's gone already). */
export function pickUpLoot(state, dropId) {
  const item = (state.dropped ?? []).find((d) => d.id === dropId) ?? null;
  if (!item) return { state, item: null };
  return { state: { ...state, dropped: state.dropped.filter((d) => d.id !== dropId) }, item };
}

/**
 * F26: an Entity the Storyteller ticks into the raid after it began is made ready for it once (as a new raid makes
 * ready the Entities in it). Returns the state with it marked, or the same state if it was already, or if this raid
 * is from before the mark was kept (readied null: nobody is made ready twice).
 */
export function markReadied(state, actorId) {
  if (!Array.isArray(state.readied) || state.readied.includes(actorId)) return state;
  return { ...state, readied: [...state.readied, actorId] };
}

/** The Storyteller steps a Turn back: the Turn that ended didn't end after all, so its furniture event stops counting. */
export function undoEndOfTurnFurniture(state) {
  const turn = state.dawn ? state.turn : state.turn - 1;
  const eventId = furnitureEventId(turn);
  return state.ledger.some((e) => e.eventId === eventId) ? cancel(state, eventId) : state;
}

/** The piece's state, set (the Storyteller's hand, or the rules below). */
export function setFurniture(state, furniture) {
  if (!FURNITURE_STATES.includes(furniture)) throw new Error(`unknown furniture state: ${furniture}`);
  if (state.furniture === furniture) return state;
  const first = state.furniture === "" && furniture === "inPlay"; // V26: the Turn of the first take
  return { ...state, furniture, furnitureLost: furniture === "lost", ...(first ? { furnitureTakenTurn: state.turn } : {}) };
}

/** F15 (Chapter 6, Captured): a furniture carrier was captured: the piece is gone for the night. */
export function loseFurniture(state) {
  return setFurniture(state, "lost");
}

/** V4: the piece is taken (first picked up): it's in play — noisy each Turn — until it leaves town or is lost. */
export function takeFurniture(state) {
  return state.furniture === "" ? setFurniture(state, "inPlay") : state;
}

/**
 * V4: the party leaves town (the way out beaten, or the final flight escaped). Only a carried piece
 * leaves town ("out"); one set down stays put, abandoned ("lost"). Either way it makes no more noise.
 */
export function furnitureLeaves(state, { carried = true } = {}) {
  return state.furniture === "inPlay" ? setFurniture(state, carried ? "out" : "lost") : state;
}

/**
 * The party has left town ("wayOut" | "flight"): from now on no hunt or chase starts, dawn included.
 * The piece goes with it if carried, or stays put, abandoned (furnitureLeaves); partyOut.piece remembers which.
 */
export function leaveTown(state, how, { carried = true } = {}) {
  if (state.partyOut) return state;
  const s = furnitureLeaves(state, { carried });
  return { ...s, partyOut: { how, turn: state.turn, piece: s.furniture !== state.furniture ? s.furniture : "" } };
}

/**
 * The Storyteller takes back a mistaken leaving of town: the party is in town again. A piece that leaving
 * took out of town or left behind (and nobody has changed since) is in play again: it was taken; and the way-out roll
 * that took them out no longer counts as this Turn's (R4). Nothing else changes.
 */
export function backInTown(state) {
  if (!state.partyOut) return state;
  const s = { ...state, partyOut: null };
  // R4: the way-out roll that took the party out is taken back with it: the way out can be rolled again this Turn
  if (state.partyOut.how === "wayOut" && state.wayOutTurn === state.partyOut.turn) s.wayOutTurn = 0;
  const piece = state.partyOut.piece;
  return piece && state.furniture === piece ? setFurniture(s, "inPlay") : s;
}
