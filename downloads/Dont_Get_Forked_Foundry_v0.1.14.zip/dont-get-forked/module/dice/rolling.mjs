/**
 * DON'T GET FORKED — rolling at the table (UI and Foundry plumbing only)
 * ---------------------------------------------------------------------
 * The roll dialog (DialogV2) collects the player's choices; buildRollPlan and
 * resolvePlannedRoll (module/logic/roll-plan.mjs) decide everything the book
 * decides. This file only rolls the dice, writes the roller's own Entity (its
 * charges, a Critical's charge back, Jekyll → Hyde), asks the GM to charge any
 * helpers and to raise Suspicion, and posts the card.
 *
 * Also here: spending a charge from the sheet, and the Draught (Jekyll & Hyde).
 */
import { SYSTEM_ID, SETTINGS, OPS, HOOKS, CARD, ACTOR_TYPES } from "../contracts.mjs";
import { DGF } from "../config.mjs";
import { buildRollPlan, resolvePlannedRoll, planOdds, chargesAfter } from "../logic/roll-plan.mjs";
import { rollAbilities, otherForm, diceFor, payFor, draughtPlan, isInRaid } from "../logic/entity.mjs";
import { runOp } from "../net/gm-ops.mjs";
import { setting } from "../settings.mjs";
import { getRaid } from "../raid/store.mjs";
import { chaseRollContext, lockupDifficulty, entities, pieceHeldNow } from "../raid/chase-flow.mjs";
import { awaitsRoll, groupEventId } from "../logic/checks.mjs";
import { inLocalChase, chaseRise, overdrawsBy } from "../logic/chase.mjs";
import { turnMarkApplies, wayOutRolled } from "../logic/raid.mjs";
import { findEntity } from "../logic/entity.mjs";
import { postCard } from "../chat/cards.mjs";
import { t, traitLabel, dieLabel, planText, traitList } from "../helpers/i18n.mjs";

const DIALOG_TEMPLATE = `systems/${SYSTEM_ID}/templates/apps/roll-dialog.hbs`;
const plain = (v) => JSON.parse(JSON.stringify(v ?? {}));
const isEntity = (a) => a?.type === ACTOR_TYPES.entity;

/* ------------------------------------------------------- input -- */

/**
 * The abilities an Entity may spend on a roll: its signature and Gift (rollAbilities); in a chase also the Draught,
 * which then goes only as a raise (D6b: any ability may be spent as a raise in the final flight; 2026-10-21: on your own
 * roll in a local chase too).
 */
function spendable(system, inChase) {
  const list = rollAbilities(system);
  const sig = findEntity(system?.entityKey)?.signature;
  if (inChase && sig?.effect === "form") list.unshift({ slot: "signature", name: sig.name, effect: "form", trait: null, noLoot: false, watchedOnly: false });
  return list;
}

/**
 * Every ability that could go on this actor's roll: its own (signature and Gift), then the other Entities' (helping
 * costs the helper's charge, Chapter 3). D6b: once the whole town hunts, each one can also be spent as a raise
 * (`canRaise`, the dialog's "or as a raise" tick); one that can do nothing else on a flight roll (an approach of
 * one's own, the Draught, a friend's approach) goes only as a raise (`raiseOnly`). 2026-10-21: in a local chase too,
 * the runner's own abilities (the ones that never work in a chase included); a friend's helps nobody there.
 */
export function abilityChoices(actor, raid = getRaid()) {
  const hunt = !!raid.hunt;
  const local = !hunt && inLocalChase(raid.chase, actor.id);
  const entry = (a, owner, own) => ({
    ...a,
    id: `ability:${owner.id}:${a.slot}`,
    payerId: owner.id,
    payerName: owner.name,
    own,
    canRaise: (hunt || (local && own)) && a.effect !== "raise",
    raiseOnly: (hunt || (local && own)) && (a.effect === "form" || a.effect === "open"),
    // 2026-10-21: once per flight (B3), and once per local chase (overdrawsBy: on its rolls or from the sheet)
    payer: { charges: owner.system.charges?.value ?? 0, overdrewInFlight: !!owner.system.overdrewInFlight,
      overdrewInChase: local && own && overdrawsBy(raid.chase, owner.id) > 0,
      carrying: (owner.system.carried?.length ?? 0) > 0 || !!owner.system.carryingFurniture }, // V17: a helper is at the same place
  });
  const own = spendable(actor.system, hunt || local).map((a) => entry(a, actor, true));
  // in a local chase, abilities help only your own roll; in the final flight, only those fleeing can help (and a
  // friend's approach of its own, or its Draught, only as a raise)
  const flight = raid.hunt && raid.chase && !raid.chase.outcome && raid.chase.kind === "final" ? new Set(raid.chase.members.map((m) => m.actorId)) : null;
  const helpers = game.actors.filter((a) => isEntity(a) && a.id !== actor.id && a.system.entityKey && isInRaid(a.system) && (!flight || flight.has(a.id)))
    .flatMap((h) => spendable(h.system, hunt).filter((a) => hunt || a.effect !== "open").map((a) => entry(a, h, false)));
  return [...own, ...helpers];
}

/** The abilities chosen in the dialog (ids; "<id>:raise" spends that ability as a raise, D6b), for the roll plan. */
function chosenAbilities(actor, raid, ids) {
  const chosen = new Set(ids ?? []);
  const out = [];
  for (const a of abilityChoices(actor, raid)) {
    if (chosen.has(a.id) && !a.raiseOnly) out.push(a);
    if (chosen.has(`${a.id}:raise`) && a.canRaise) out.push({ ...a, asRaise: true });
  }
  return out;
}

/**
 * Where this roll is, from the raid: the chase this Entity is in (its round, the ground,
 * the mob, its Weakness), the lock-up (a captive slips free, anyone else rescues), the
 * open group check. Plain data for the dialog and the card.
 */
export function rollSituation(actor, values, raid = getRaid()) {
  const chase = values.chase ? chaseRollContext(actor, raid) : null;
  const lockup = values.lockup ? (actor.system.status === "captured" ? "slip" : "rescue") : "";
  const group = values.group && awaitsRoll(raid.group, actor.id) ? raid.group : null;
  return { chase, lockup, group };
}

/** The roll plan's input from the dialog's values (see module/logic/roll-plan.mjs). */
export function buildInput(actor, values, raid = getRaid()) {
  const where = rollSituation(actor, values, raid);
  const c = where.chase;
  let difficulty = values.difficulty;
  if (values.wayOut) difficulty = DGF.labels[raid.difficulty]?.exit ?? values.difficulty; // the way out: the label's exit Difficulty
  else if (where.lockup) difficulty = lockupDifficulty(raid); // the lock-up: the label's lock-up Difficulty
  else if (c?.ok) difficulty = c.difficulty; // a chase: the mob's Difficulty
  return {
    roller: { id: actor.id, system: plain(actor.system) },
    trait: values.trait,
    second: values.second,
    difficulty,
    abilities: chosenAbilities(actor, raid, values.abilities),
    duty: !!values.duty && !c,
    stRaise: !!values.stRaise,
    loud: !!values.loud,
    watched: !!values.watched,
    wayOut: !!values.wayOut,
    wayOutRolled: !!values.wayOut && setting(SETTINGS.wayOutOncePerTurn) && wayOutRolled(raid), // R4: once a Turn
    pieceHeld: !!values.wayOut && setting(SETTINGS.hugePieceHeld) && pieceHeldNow(raid), // W4 (2026-10-21): the Huge piece waits for the chase
    localOverdrawOnce: setting(SETTINGS.localOverdrawOnce), // 2026-10-21: one overdraw per runner per local chase
    partyPerks: values.wayOut ? entities().filter((a) => a.id !== actor.id && a.system.status !== "captured").map((a) => a.system.perk) : [], // Fetch (B5)
    chase: !!values.chase,
    hunt: raid.hunt,
    chaseTraits: c?.ok ? c.traits : null,
    chaseBlocked: c && !c.ok ? c.reason : "",
    weakness: !!c?.ok && c.weakness,
    lockup: where.lockup,
    furniture: !!values.furniture,
    companionCarrying: !!values.companionCarrying,
    turn: raid.turn,
  };
}

/** V17 Out of Sight: does the roller's Perk ask who carries? Then the dialog has a tick for someone with it. */
const asksWhoCarries = (actor) => !!DGF.perkRules[actor.system.perk]?.withYou;

/** The tick's start: another Entity in the raid carries loot or furniture (the system can't tell who is where). */
function someoneElseCarries(actor) {
  return entities().some((a) => a.id !== actor.id && ((a.system.carried?.length ?? 0) > 0 || a.system.carryingFurniture));
}

/** The dialog's values from its form. */
export function readRollForm(form, choices) {
  const el = (n) => form?.elements?.namedItem?.(n) ?? null;
  const on = (n) => !!el(n)?.checked;
  return {
    trait: el("trait")?.value,
    second: el("second")?.value,
    difficulty: Number(el("difficulty")?.value),
    abilities: [...choices.filter((c) => on(c.id)).map((c) => c.id), ...choices.filter((c) => on(`${c.id}:raise`)).map((c) => `${c.id}:raise`)],
    duty: on("duty"),
    stRaise: on("stRaise"),
    loud: on("loud"),
    watched: on("watched"),
    wayOut: on("wayOut"),
    chase: on("chase"),
    lockup: on("lockup"),
    group: on("group"),
    furniture: on("furniture"),
    companionCarrying: on("companionCarrying"),
  };
}

function oddsLine(plan) {
  if (!plan?.ok) return plan?.errors?.map(planText).join(" ") ?? "";
  const o = planOdds(plan);
  const pc = (x) => `${Math.round(x * 100)}%`;
  const parts = [`${t("DGF.Band.success")} ${pc(o.success)}`, `${t("DGF.Band.cost")} ${pc(o.cost)}`, `${t("DGF.Band.trouble")} ${pc(o.trouble)}`];
  if (plan.second === "monster" && !plan.hidden) parts.push(`${t("DGF.MonsterShows")} ${pc(o.show)}`);
  return `${t("DGF.Roll.dice", { trait: dieLabel(plan.traitDie), second: dieLabel(plan.secondDie), difficulty: plan.difficulty })} — ${parts.join(" · ")}`;
}

function dialogContext(actor, values, raid) {
  const sys = actor.system;
  const choices = abilityChoices(actor);
  const chosen = new Set(values.abilities ?? []);
  const duty = DGF.duties.find((d) => d.key === sys.duty);
  const notices = [];
  if (raid.hunt) notices.push(t("DGF.Roll.notice.hunt"), t("DGF.Roll.notice.flightRaise"));
  else if (inLocalChase(raid.chase, actor.id)) notices.push(t("DGF.Roll.notice.localRaise"));
  if (raid.hunt && sys.overdrewInFlight) notices.push(t("DGF.Roll.notice.overdrawStep"));
  if (setting(SETTINGS.wayOutOncePerTurn) && wayOutRolled(raid)) notices.push(t("DGF.Roll.notice.wayOutRolled"));
  if (setting(SETTINGS.hugePieceHeld) && pieceHeldNow(raid)) notices.push(t("DGF.Roll.notice.pieceHeld"));
  if (sys.carryingFurniture) notices.push(t("DGF.Roll.notice.carrying"));
  if (sys.nextRollSmaller > 0) notices.push(t("DGF.Roll.notice.smaller", { n: sys.nextRollSmaller }));
  if (sys.weaknessInPlay) notices.push(t("DGF.Roll.notice.weakness"));
  if (sys.status === "captured") notices.push(t("DGF.Roll.notice.captured"));
  if (!isInRaid(sys)) notices.push(t("DGF.Roll.notice.notInRaid"));
  if (raid.group?.open && raid.group.rolls?.[actor.id]?.passed) notices.push(t("DGF.Roll.notice.spectral", { label: raid.group.label || t("DGF.Group.unnamed") })); // V19
  const where = rollSituation(actor, { ...values, chase: true, lockup: true, group: true }, raid);
  const c = where.chase;
  // a Turn's marks speak to that Turn's raid rolls (a chase roll, the final flight's included, isn't one of its actions):
  // a lost Turn (a Cost), and V25 rolling again in the Turn it picked up
  if (turnMarkApplies(raid, sys.skipTurn, { chaseRoll: !!c?.ok })) notices.push(t("DGF.Roll.notice.skipTurn", { turn: raid.turn }));
  if (turnMarkApplies(raid, sys.pickedUpTurn, { chaseRoll: !!c?.ok })) notices.push(t("DGF.Roll.notice.pickedUp", { items: sys.pickedUp }));
  // Wall-Crawler: in a chase his Nimble die is one size bigger, the roll's one raise (the plan applies it; this says so)
  const chaseRaise = DGF.perkRules[sys.perk]?.chaseRaise;
  if (chaseRaise && (c?.ok || raid.hunt)) {
    const perk = findEntity(sys.entityKey)?.perks?.find((k) => k.key === sys.perk)?.name ?? sys.perk;
    notices.push(t("DGF.Roll.notice.chaseRaise", { perk, trait: traitLabel(chaseRaise) }));
  }
  if (c?.ok) {
    const ground = DGF.chaseTable[c.ground.face - 1]?.name ?? "";
    notices.push(t("DGF.Roll.notice.chase", { kind: t(`DGF.Chase.kind.${c.kind}`), round: c.round, ground, traits: traitList(c.traits), mob: c.difficulty }));
    if (c.weakness) notices.push(t("DGF.Roll.notice.chaseWeakness"));
    if (c.local) notices.push(t("DGF.Roll.notice.chaseRise", { n: chaseRise(raid.chase).total })); // D1
  } else if (c) notices.push(t(`DGF.Plan.${c.reason}`));
  // B7: an approach only at a watched obstacle (Mesmerize) isn't offered until Watched, the way out or the lock-up is ticked
  const watchedHere = !!(values.watched || values.wayOut || values.lockup);
  const describe = (a) => ({
    id: a.id, name: a.name, helper: a.payerName, charges: a.payer.charges,
    effectText: a.raiseOnly ? t("DGF.Effect.raiseOnly") : a.watchedOnly ? t("DGF.Effect.openWatched", { trait: traitLabel(a.trait) }) : t(`DGF.Effect.${a.effect}`, { trait: traitLabel(a.trait) }),
    watchedOnly: !!a.watchedOnly && !a.raiseOnly,
    disabled: !!a.watchedOnly && !a.raiseOnly && !watchedHere,
    checked: chosen.has(a.id) && !(a.watchedOnly && !watchedHere),
    // D6b: in the final flight, spend it as a raise instead (the only way for raiseOnly ones)
    raiseOnly: !!a.raiseOnly,
    canRaise: !!a.canRaise,
    raiseId: `${a.id}:raise`,
    raiseChecked: chosen.has(`${a.id}:raise`),
  });
  const plan = buildRollPlan(buildInput(actor, values, raid));
  return {
    actorName: actor.name,
    traits: DGF.traits.map((k) => ({ key: k, label: traitLabel(k), die: dieLabel(sys.traits[k]), selected: k === values.trait })),
    seconds: Object.entries(DGF.second).map(([k, d]) => ({ key: k, label: `${t(`DGF.Second.${k}`)} ${dieLabel(d)}`, selected: k === values.second })),
    // R7: an obstacle's Difficulty is just a number (6, 8, 10, 12): no words for it
    difficulties: Object.values(DGF.difficulty).map((v) => ({ value: v, label: `${v}`, selected: v === Number(values.difficulty) })),
    own: choices.filter((a) => a.own).map(describe),
    helpers: choices.filter((a) => !a.own).map(describe),
    hasHelpers: choices.some((a) => !a.own),
    duty: duty ? { label: t("DGF.Roll.duty", { duty: duty.name, kind: duty.kind }), checked: !!values.duty } : null,
    stRaise: !!values.stRaise,
    loud: !!values.loud, watched: !!values.watched, wayOut: !!values.wayOut, chase: !!values.chase,
    lockup: !!values.lockup, furniture: !!values.furniture,
    companion: asksWhoCarries(actor) ? { checked: !!values.companionCarrying } : null,
    lockupLabel: t(sys.status === "captured" ? "DGF.Roll.lockupSlip" : "DGF.Roll.lockupRescue", { difficulty: lockupDifficulty(raid) }),
    group: where.group ? { checked: !!values.group, label: t("DGF.Roll.group", { label: where.group.label || t("DGF.Group.unnamed") }) } : null,
    exit: DGF.labels[raid.difficulty]?.exit,
    wayOutLabel: t("DGF.Roll.wayOut", { difficulty: DGF.labels[raid.difficulty]?.exit }),
    notices,
    showOdds: setting(SETTINGS.showOdds),
    odds: oddsLine(plan),
    problems: [...plan.errors, ...plan.warnings].map(planText),
  };
}

/** Wire the live odds line (a real browser only; harmless if the DOM differs). */
function liveOdds(actor, raid, choices) {
  return (event, dialog) => {
    try {
      const root = dialog?.element ?? event?.target?.element ?? null;
      const form = root?.querySelector?.("form") ?? root;
      const out = root?.querySelector?.(".dgf-odds");
      if (!form || !out) return;
      const update = () => {
        // B7: Mesmerize is on offer only while Watched, the way out or the lock-up is ticked
        const named = (n) => form.elements?.namedItem?.(n);
        const watchedHere = ["watched", "wayOut", "lockup"].some((n) => named(n)?.checked);
        for (const box of root.querySelectorAll?.("input[data-watched-only]") ?? []) {
          box.disabled = !watchedHere;
          if (!watchedHere) box.checked = false;
        }
        try { out.textContent = oddsLine(buildRollPlan(buildInput(actor, readRollForm(form, choices), raid))); } catch (err) { /* keep the last line */ }
      };
      root.addEventListener("change", update);
    } catch (err) { console.warn("Don't Get Forked | live odds unavailable", err); }
  };
}

/** Open the roll dialog; resolves to its values, or null if cancelled. */
export async function promptRoll(actor, values) {
  const raid = getRaid();
  const choices = abilityChoices(actor);
  const content = await foundry.applications.handlebars.renderTemplate(DIALOG_TEMPLATE, dialogContext(actor, values, raid));
  const answer = await foundry.applications.api.DialogV2.wait({
    window: { title: t("DGF.Roll.title", { name: actor.name }) },
    classes: ["dont-get-forked", "dgf-roll-dialog"],
    position: { width: 460 },
    content,
    buttons: [
      { action: "roll", label: t("DGF.Roll.roll"), icon: "fa-solid fa-dice", default: true, callback: (event, button) => readRollForm(button.form, choices) },
      { action: "cancel", label: t("DGF.Dialog.cancel") },
    ],
    render: liveOdds(actor, raid, choices),
    rejectClose: false,
  });
  return answer && typeof answer === "object" ? answer : null;
}

/* -------------------------------------------------------- roll -- */

/** Open the dialog for a trait and roll (asking again if the choices break a rule). */
export async function rollEntity(actor, { trait = "", chase = null } = {}) {
  if (!isEntity(actor) || !actor.system.entityKey) return null;
  if (!actor.isOwner) { ui.notifications.warn(t("DGF.Notify.notOwner")); return null; }
  const raid = getRaid();
  // where the Entity is: in a chase (its round), held at the lock-up, in an open group check
  const inChase = chase ?? !!chaseRollContext(actor, raid);
  const captive = actor.system.status === "captured";
  const ctx = inChase ? chaseRollContext(actor, raid) : null;
  const best = (list) => [...list].sort((a, b) => (actor.system.traits[b] ?? 0) - (actor.system.traits[a] ?? 0))[0];
  const pick = trait || (ctx?.ok ? best(ctx.traits) : captive ? best(DGF.lockup.slip.quiet) : "brawn");
  let values = {
    trait: pick, second: raid.hunt || actor.system.carryingFurniture ? "monster" : "mask",
    difficulty: DGF.difficulty.standard, abilities: [], chase: raid.hunt || inChase,
    lockup: captive, group: awaitsRoll(raid.group, actor.id),
    companionCarrying: asksWhoCarries(actor) && someoneElseCarries(actor),
  };
  for (let i = 0; i < 5; i++) {
    const answer = await promptRoll(actor, values);
    if (!answer) return null;
    const result = await performRoll(actor, answer);
    if (result.ok) return result;
    ui.notifications.warn(result.plan.errors.map(planText).join(" "));
    values = answer;
  }
  return null;
}

/** Roll with these values (no dialog): plan, pay, roll, post the card, raise Suspicion. */
export async function performRoll(actor, values) {
  const raid = getRaid();
  const plan = buildRollPlan(buildInput(actor, values, raid));
  if (!plan.ok) return { ok: false, plan };
  const autoCharges = setting(SETTINGS.autoCharges);
  // Helpers' charges are spent by the GM from the posted card (the roller doesn't own their Entities): see below.
  const helpersOwe = plan.payments.some((p) => !p.own && ((autoCharges && p.spend > 0) || p.step));

  const traitRoll = await new Roll(`1d${plan.traitDie}`).evaluate();
  const secondRoll = await new Roll(`1d${plan.secondDie}`).evaluate();
  const res = resolvePlannedRoll(plan, traitRoll.total, secondRoll.total);

  // The roller's own Entity: charges spent and a Critical's charge back, the used Cost, the change of form.
  const sys = actor.system;
  const own = plan.payments.find((p) => p.own);
  const update = {};
  const before = sys.charges.value;
  let after = before;
  if (autoCharges) {
    // a Critical gives a spent charge back up to the raid's starting number: the Entity's own, plus any castle upgrades (campaign)
    after = chargesAfter({ value: before, start: sys.charges.start + (sys.charges.extra ?? 0), spent: own?.spend ?? 0, chargeBack: res.chargeBack });
    if (after !== before) update["system.charges.value"] = after;
  }
  if (own?.step) update["system.overdrewInFlight"] = true; // 2026-10-21: its own step down from the next roll; once per flight (B3)
  if (plan.consumeSmaller) update["system.nextRollSmaller"] = 0;
  let formTo = "";
  if (res.formShift && setting(SETTINGS.autoForm)) {
    formTo = otherForm(sys.entityKey, sys.form) ?? "";
    if (formTo) { update["system.form"] = formTo; update["system.traits"] = diceFor(sys.entityKey, formTo); }
  }
  if (Object.keys(update).length) await actor.update(update);

  // the HUD's reason: the roll's biggest trigger, and any overdraw on top (D3)
  const top = [...res.riseKeys, ...(res.overdrawRise ? ["overdraw"] : [])];
  const where = rollSituation(actor, values, raid);
  const chaseCtx = where.chase?.ok && plan.tracked ? where.chase : null;
  const groupId = where.group && setting(SETTINGS.autoGroupChecks) ? where.group.id : "";
  const card = {
    v: 1, kind: CARD.roll, raidId: raid.raidId,
    eventId: groupId ? groupEventId(groupId) : `roll:${foundry.utils.randomID()}`,
    groupId, lockup: plan.lockup, furniture: plan.furniture,
    chaseId: chaseCtx?.chaseId ?? "", chaseRound: chaseCtx?.round ?? 0, chaseKind: chaseCtx?.kind ?? "",
    groundName: chaseCtx ? DGF.chaseTable[chaseCtx.ground.face - 1]?.name ?? "" : "",
    chaseShared: !!chaseCtx && (chaseCtx.kind === "final" || (raid.chase?.members?.length ?? 0) > 1),
    leadMove: res.leadMove, freed: res.freed, rescued: res.rescued, slipTrouble: res.slipTrouble, wayOutBeaten: res.wayOutBeaten,
    chaseStarted: "", freedNames: [], gmSeen: false,
    actorId: actor.id, actorName: actor.name, userId: game.user.id, turn: raid.turn,
    calledTrait: plan.calledTrait, trait: plan.trait, baseDie: plan.baseDie, traitDie: plan.traitDie,
    second: plan.second, secondDie: plan.secondDie, baseDifficulty: plan.baseDifficulty, difficulty: plan.difficulty,
    diffParts: plan.diffParts, downParts: plan.downParts, raises: plan.raises, duty: plan.duty, stRaise: plan.stRaise, perkRaise: plan.perkRaise, open: plan.open, hidden: plan.hidden,
    loud: plan.loud, watched: plan.watched, wayOut: plan.wayOut, chase: plan.chase, hunt: plan.hunt,
    abilities: plan.abilities.map((a) => ({ name: a.name, effect: a.effect, trait: a.trait, payerId: a.payerId, payerName: a.payerName, own: a.payerId === actor.id, asRaise: !!a.asRaise })),
    payments: plan.payments.map((p) => ({ payerId: p.payerId, payerName: p.payerName, own: p.own, uses: p.uses, spend: p.spend, overdraw: p.overdraw, step: p.step })),
    warnings: plan.warnings.map((w) => w.code),
    traitFace: res.traitFace, secondFace: res.secondFace, total: res.total, band: res.band, critical: res.critical,
    showed: res.showed, show: res.show, hiddenShow: res.hiddenShow, triggers: res.triggers, suspicion: res.suspicion,
    rise: res.rise, overdrawRise: res.overdrawRise, suspicionLabel: top.join(","),
    // D1: a local chase roll raises nothing now; what it would waits for the chase's one rise when it ends
    localChase: plan.chase && !plan.hunt, chaseRise: res.chaseRise, chaseRiseKeys: res.chaseRiseKeys, chaseOverdraws: res.chaseOverdraws, caught: res.caught, troubleUnwatched: res.troubleUnwatched, unseen: res.unseen,
    outOfSight: plan.caughtOnlyCarrying, carryingBy: plan.carryingBy, carryingName: plan.carryingName,
    formShift: res.formShift, formTo, chargeBack: res.chargeBack, costs: res.costs,
    autoCharges, chargesBefore: before, chargesAfter: after, helpersPaid: !helpersOwe,
    applied: false, cancelled: false, cost: "", skipTurn: 0, dropped: "",
  };
  const message = await postCard(card, { speaker: ChatMessage.getSpeaker({ actor }), rolls: [traitRoll, secondRoll] });
  // the helpers pay what the card says, once (if no Storyteller is connected, when one returns: reconcile)
  if (helpersOwe) await runOp(OPS.actorSpendCharges, { messageId: message.id });
  // a roll the raid follows (a group check, a chase round, a capture, the lock-up, the way out: R4 marks it rolled this
  // Turn) goes to the GM whole; any other roll only for its Suspicion
  const tracked = card.groupId || card.chaseId || card.lockup || card.caught || card.wayOutBeaten || (card.wayOut && !card.chase);
  if (tracked) await runOp(OPS.raidRoll, { messageId: message.id });
  else if (res.suspicion > 0 && !plan.hunt && setting(SETTINGS.autoSuspicion)) await runOp(OPS.raidApplyCard, { messageId: message.id });
  Hooks.callAll(HOOKS.rollResolved, message, card);
  return { ok: true, message, card, plan, result: res };
}

/* ------------------------------------------- charges outside a roll -- */

/** D1 + D3: is this Entity in a running local chase the raid tracks (an overdraw then adds to the chase's one rise)? */
const inTrackedLocal = (actor, raid) => inLocalChase(raid.chase, actor.id);

async function confirmOverdraw(actor, pay, raid = getRaid()) {
  const key = pay.step ? "DGF.Overdraw.step" : inTrackedLocal(actor, raid) ? "DGF.Overdraw.chase" : "DGF.Overdraw.suspicion";
  return foundry.applications.api.DialogV2.confirm({
    window: { title: t("DGF.Overdraw.title") },
    content: `<p>${t(key, { name: foundry.utils.escapeHTML(actor.name), n: DGF.suspicion.overdraw })}</p>`,
    rejectClose: false,
  });
}

/**
 * The card for an ability used outside a roll (the sheet's spend, the Draught). Its overdraw raises Suspicion +2 now
 * — or, in a local chase, adds +2 to the chase's one rise when it ends (D1 + D3: the card goes to the chase).
 */
async function postAbilityCard(actor, fields, raid) {
  const chase = !raid.hunt && fields.suspicion > 0 && inTrackedLocal(actor, raid) ? raid.chase : null;
  const card = {
    v: 1, kind: CARD.ability, raidId: raid.raidId, eventId: `ability:${foundry.utils.randomID()}`,
    actorId: actor.id, actorName: actor.name, userId: game.user.id, turn: raid.turn, hunt: raid.hunt,
    applied: false, cancelled: false, suspicionLabel: "overdraw", ...fields,
    ...(chase ? { chaseId: chase.id, chaseOverdraws: fields.overdraw || 1, suspicion: 0 } : {}),
  };
  const message = await postCard(card, { speaker: ChatMessage.getSpeaker({ actor }) });
  if (chase) await runOp(OPS.raidApplyCard, { messageId: message.id });
  else if (card.suspicion > 0 && !raid.hunt && setting(SETTINGS.autoSuspicion)) await runOp(OPS.raidApplyCard, { messageId: message.id });
  return message;
}

/** 2026-10-21: what one overdraw per local chase needs to know about this Entity (the switch localOverdrawOnce). */
function localOnce(actor, raid) {
  const on = !raid.hunt && setting(SETTINGS.localOverdrawOnce) && inTrackedLocal(actor, raid);
  return { localChase: on, overdrewInChase: on && overdrawsBy(raid.chase, actor.id) > 0 };
}
const refusalCode = (refusal) => (refusal === "onceLocal" ? "overdrawOnceLocal" : "overdrawOnce");

/** The sheet's "spend a charge": one use of an ability outside the roll dialog (overdraw at zero). */
export async function spendCharge(actor) {
  if (!isEntity(actor) || !actor.isOwner) return null;
  const raid = getRaid();
  const sys = actor.system;
  const pay = payFor({ charges: sys.charges.value, uses: 1, hunt: raid.hunt, overdrewInFlight: sys.overdrewInFlight, ...localOnce(actor, raid) });
  if (!pay.allowed) { ui.notifications.warn(planText({ code: refusalCode(pay.refusal), name: actor.name })); return null; }
  if (pay.overdraw && !(await confirmOverdraw(actor, pay, raid))) return null;
  const autoCharges = setting(SETTINGS.autoCharges);
  const update = {};
  if (autoCharges && pay.spend) update["system.charges.value"] = sys.charges.value - pay.spend;
  if (pay.step) update["system.overdrewInFlight"] = true; // 2026-10-21: its own step down from the next roll
  const before = sys.charges.value;
  if (Object.keys(update).length) await actor.update(update);
  return postAbilityCard(actor, { action: "spend", spend: pay.spend, overdraw: pay.overdraw, suspicion: pay.suspicion, step: pay.step, autoCharges, chargesBefore: before, chargesAfter: actor.system.charges.value }, raid);
}

/** The Draught (Jekyll & Hyde): change form; one charge, free back to Jekyll with Practiced Hand. */
export async function drinkDraught(actor) {
  if (!isEntity(actor) || !actor.isOwner) return null;
  const raid = getRaid();
  const plan = draughtPlan(actor.system, { hunt: raid.hunt, ...localOnce(actor, raid) });
  if (!plan) return null;
  if (!plan.allowed) { ui.notifications.warn(planText({ code: refusalCode(plan.refusal), name: actor.name })); return null; }
  if (plan.overdraw && !(await confirmOverdraw(actor, plan, raid))) return null;
  const autoCharges = setting(SETTINGS.autoCharges);
  const before = actor.system.charges.value;
  const update = { "system.form": plan.to, "system.traits": plan.traits };
  if (autoCharges && plan.spend) update["system.charges.value"] = before - plan.spend;
  if (plan.step) update["system.overdrewInFlight"] = true; // 2026-10-21: its own step down from the next roll
  await actor.update(update);
  return postAbilityCard(actor, { action: "draught", name: actor.system.view?.signature?.name ?? "", formFrom: plan.from, formTo: plan.to, cost: plan.cost, spend: plan.spend, overdraw: plan.overdraw, suspicion: plan.suspicion, step: plan.step, autoCharges, chargesBefore: before, chargesAfter: actor.system.charges.value }, raid);
}
