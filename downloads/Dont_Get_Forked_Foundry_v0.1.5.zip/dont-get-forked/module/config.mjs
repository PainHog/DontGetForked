/**
 * DON'T GET FORKED — System Configuration
 * ---------------------------------------
 * Static, version-agnostic game data lives here (attributes, tracks, tables …)
 * so data models, sheets, dice code and the pure rules logic can all share it
 * without importing any Foundry API. Pure data only: no `game`, `ui`, `foundry`
 * or DOM, so `module/logic/` and the simulator (`sim/`) can import it under plain
 * Node.
 *
 * Source: docs/CORE-RULES.md 1.0 (approved 2026-10-05) until the rulebook chapters
 * exist; then the rulebook (book/src/chapters/) is the source of truth and this file
 * follows it, never the other way round. Labels live in lang/en.json.
 */

export const DGF = {};

/** The system id (must match system.json "id" and contracts.mjs SYSTEM_ID). */
DGF.id = "dont-get-forked";

/** CORE-RULES Entities: the five traits. */
DGF.traits = Object.freeze(["brawn", "nimble", "sly", "charm", "wits"]);

/** CORE-RULES Entities: every Entity has one each of these, placed differently. */
DGF.dieSteps = Object.freeze([4, 6, 8, 10, 12]);

/**
 * The eight Entities' dice (C1) and signature abilities (C2), approved by Richard
 * 2026-10-05 (rulebook Chapter 2). Jekyll & Hyde is one sheet with two arrangements
 * of the same dice (`forms`). A signature does one standard effect (with its trait
 * for "switch" and "open"); Jekyll & Hyde's is "form": The Draught changes Jekyll to
 * Hyde or back (one charge), and the Monster showing on a Jekyll roll turns him into
 * Hyde for free (C2b). A signature's `text` is the book's line after "(signature):"; a
 * Gift version's `text` is its flavour line (its rule is the standard effect's wording).
 * Gifts, Perks, Weaknesses and Tells: C3–C9 (rulebook Chapter 2).
 */
DGF.entities = Object.freeze([
  { key: "dracula", name: "Dracula", duty: "butler", dice: { brawn: 8, nimble: 10, sly: 6, charm: 12, wits: 4 }, signature: { name: "Mesmerise", effect: "open", trait: "charm", watchedOnly: true, text: "open an approach with Charm at a watched obstacle. He bends a mind with a look.", flavour: "He bends a mind with a look." },
    gift: {
      name: "Shape of the Night",
      versions: [
        { key: "bat", name: "Bat", effect: "switch", trait: "nimble", text: "He flits up to the window.", default: true },
        { key: "mist", name: "Mist", effect: "hidden", text: "If he shows, it’s only fog." },
        { key: "wolf", name: "Wolf", effect: "raise", text: "The strength and speed of a wolf." },
      ],
    },
    perks: [
      { key: "hypnoticEyes", name: "Hypnotic Eyes", text: "On Charm rolls, the Monster shows only if it beats your trait die by 2 or more.", default: true },
      { key: "oldMoney", name: "Old Money", text: "A Cost on a Charm roll is never Suspicion +1." },
      { key: "wallCrawler", name: "Wall-Crawler", text: "In a chase you can always roll Nimble, whatever the ground, and your Nimble die is one size bigger (the roll’s one raise)." },
    ],
    weakness: { name: "Garlic", timing: "always", text: "Every kitchen in town has some, and the mob knows it." },
    tell: { name: "No Reflection", text: "A shop window shows everyone but him." },
  },
  { key: "creature", name: "Frankenstein’s Creature", duty: "handyman", dice: { brawn: 12, nimble: 8, sly: 6, charm: 4, wits: 10 }, signature: { name: "Brute Force", effect: "switch", trait: "brawn", text: "use Brawn instead of the trait called. Stronger than any man, it breaks what others pick.", flavour: "Stronger than any man, it breaks what others pick." },
    gift: {
      name: "Made, Not Born",
      versions: [
        { key: "mountainStride", name: "Mountain Stride", effect: "open", trait: "nimble", text: "He bounds over walls the way he crossed the glaciers.", default: true },
        { key: "hovelWatcher", name: "Hovel Watcher", effect: "hidden", text: "He learned to watch unseen." },
        { key: "bookLearned", name: "Book-Learned", effect: "raise", text: "He taught himself from books." },
      ],
    },
    perks: [
      { key: "strongBack", name: "Strong Back", text: "You carry a Huge piece alone." },
      { key: "tireless", name: "Tireless", text: "Carrying doesn’t make your Nimble smaller.", default: true },
      { key: "builtToLast", name: "Built to Last", text: "You slip free from the lock-up on a Success or a Cost." },
    ],
    weakness: { name: "Fire", timing: "soon", text: "Someone has to light the torches." },
    tell: { name: "Head and Shoulders", text: "He stands a head above the whole crowd, and no costume hides it." },
  },
  { key: "mummy", name: "The Mummy", duty: "librarian", dice: { brawn: 10, nimble: 4, sly: 6, charm: 8, wits: 12 }, signature: { name: "Ancient Lore", effect: "switch", trait: "wits", text: "use Wits instead of the trait called. It knew this trick three thousand years ago.", flavour: "It knew this trick three thousand years ago." },
    gift: {
      name: "Secrets of the Tomb",
      versions: [
        { key: "royalBearing", name: "Royal Bearing", effect: "open", trait: "charm", text: "They still bow to a pharaoh.", default: true },
        { key: "justACostume", name: "Just a Costume", effect: "hidden", text: "On festival night, who’d believe a real one?" },
        { key: "oldCurse", name: "Old Curse", effect: "raise", text: "A muttered curse, and the lock gives." },
      ],
    },
    perks: [
      { key: "patienceOfAges", name: "Patience of Ages", text: "“Lose a Turn” is never your Cost." },
      { key: "keeperOfTreasures", name: "Keeper of Treasures", text: "“Drop an item” is never your Cost." },
      { key: "fearTheCurse", name: "Fear the Curse", text: "When you flee alone, the mob’s Difficulty in your local chase is 1 lower: nobody wants to get too close.", flavour: "nobody wants to get too close", default: true },
    ],
    weakness: { name: "A Loose Thread", timing: "soon", text: "Once someone grabs a loose end, it all starts to unravel." },
    tell: { name: "Dust and Spice", text: "A trail of dust and a smell of old spices wherever it walks." },
  },
  { key: "werewolf", name: "The Werewolf", duty: "gardener", dice: { brawn: 10, nimble: 12, sly: 6, charm: 4, wits: 8 }, signature: { name: "Good Dog", effect: "hidden", text: "roll the Monster die without risking Suspicion. If the wolf shows, the crowd sees a very large dog.", flavour: "If the wolf shows, the crowd sees a very large dog." },
    gift: {
      name: "The Wolf Within",
      versions: [
        { key: "keenNose", name: "Keen Nose", effect: "switch", trait: "wits", text: "It smells the way in.", default: true },
        { key: "throughTheHedge", name: "Through the Hedge", effect: "open", trait: "brawn", text: "It goes straight through." },
        { key: "howl", name: "Howl", effect: "raise", text: "A howl that freezes the crowd for a moment." },
      ],
    },
    perks: [
      { key: "nightRunner", name: "Night Runner", text: "When you flee alone, your local chase starts at Lead 2.", default: true },
      { key: "shortcut", name: "Shortcut", text: "The way out’s Difficulty is 2 lower when you roll it." },
      { key: "fetch", name: "Fetch", text: "You know the way home. Two edges. While you’re at the way out, its Difficulty is 1 lower for whoever rolls it. A final flight you’re in starts at Lead 3, not 2.", flavour: "You know the way home." },
    ],
    weakness: { name: "Hounds", timing: "soon", text: "Someone lets the hunting dogs out." },
    tell: { name: "Eyebrows That Meet", text: "Brows that meet in the middle, and a little too much hair everywhere." },
  },
  { key: "invisible", name: "The Invisible Man", duty: "tailor", dice: { brawn: 4, nimble: 8, sly: 12, charm: 6, wits: 10 }, signature: { name: "Unseen", effect: "hidden", text: "roll the Monster die without risking Suspicion. When the Monster shows, there’s nothing to see.", flavour: "When the Monster shows, there’s nothing to see." },
    gift: {
      name: "A Scientist’s Tricks",
      versions: [
        { key: "throughTheGap", name: "Through the Gap", effect: "open", trait: "nimble", text: "He slips through as the door swings shut.", default: true },
        { key: "poltergeist", name: "Poltergeist", effect: "raise", text: "Things move by themselves, and everyone looks the other way." },
        { key: "workItOut", name: "Work It Out", effect: "switch", trait: "wits", text: "A scientist’s mind finds another way." },
      ],
    },
    perks: [
      { key: "outOfSight", name: "Out of Sight", text: "Trouble at a watched obstacle doesn’t get you caught unless you, or anyone in the same place, carries loot or furniture. It still raises Suspicion: they can’t see you, but they can see a floating candlestick.", flavour: "they can’t see you, but they can see a floating candlestick", default: true },
      { key: "hiddenPockets", name: "Hidden Pockets", text: "Captured, you keep the loot you carry (not furniture)." },
      { key: "lightStep", name: "Light Step", text: "The loud way costs you no Suspicion." },
    ],
    weakness: { name: "Flour", timing: "soon", text: "Someone throws a bag of flour, and there he is." },
    tell: { name: "Bandages and Goggles", text: "A wrapped head, dark goggles, a false nose, and a sneeze from nowhere." },
  },
  { key: "ghost", name: "A Ghost", duty: "butler", dice: { brawn: 4, nimble: 12, sly: 10, charm: 8, wits: 6 }, signature: { name: "Through the Wall", effect: "open", trait: "sly", noLoot: true, text: "open an approach with Sly, but not while you carry loot or furniture: nothing you carry passes through. It drifts in where there’s no door.", flavour: "It drifts in where there’s no door." },
    gift: {
      name: "Haunting",
      versions: [
        { key: "chill", name: "Chill", effect: "raise", text: "A sudden cold, and fingers fumble.", default: true },
        { key: "whisper", name: "Whisper", effect: "switch", trait: "charm", text: "A voice in the ear." },
        { key: "fade", name: "Fade", effect: "hidden", text: "A trick of the light." },
      ],
    },
    perks: [
      { key: "spectral", name: "Spectral", text: "Group obstacles (the ones each Entity must get past for itself) don’t stop you: no roll and no action, so you can still move or roll that Turn. Not while you carry loot or furniture.", default: true },
      { key: "rattle", name: "Rattle", text: "The Monster showing on your roll is Suspicion +1, not +2: nobody takes rattling chains seriously.", flavour: "nobody takes rattling chains seriously" },
      { key: "alreadyDead", name: "Already Dead", text: "Cornered in a local chase, you aren’t captured: you’re back where you were caught, still carrying what you had, and you lose your next Turn. If the chase’s rise brings the Limit, you simply join the final flight." },
    ],
    weakness: { name: "Cold Iron", timing: "always", text: "Horseshoes, railings, a poker from the fire: every street has some." },
    tell: { name: "Cold Spot", text: "Candles gutter and breath fogs wherever it drifts." },
  },
  { key: "witch", name: "A Witch", duty: "cook", dice: { brawn: 6, nimble: 4, sly: 10, charm: 8, wits: 12 }, signature: { name: "Hedge Spell", effect: "raise", text: "raise a trait die one size, on any roll in the same place, hers or a friend’s (in a local chase, only hers). Old village magic: a muttered word, a pinch of salt, and luck leans her way.", flavour: "Old village magic: a muttered word, a pinch of salt, and luck leans her way." },
    gift: {
      name: "Witchcraft",
      versions: [
        { key: "broomstick", name: "Broomstick", effect: "open", trait: "nimble", text: "In over the rooftops, quiet as an owl." },
        { key: "blackCat", name: "Black Cat", effect: "hidden", text: "Everyone blames the cat." },
        { key: "potionForThat", name: "A Potion for That", effect: "switch", trait: "wits", text: "There’s a potion for everything.", default: true },
      ],
    },
    perks: [
      { key: "familiarsWarning", name: "Familiar’s Warning", text: "When you arrive somewhere that gets a Tell check (Chapter 5), alone or with others, a Tell goes off only if a second d6 also rolls 4–6. That covers everyone arriving with you: the cat warns you.", flavour: "the cat warns you", default: true },
      { key: "flyByNight", name: "Fly by Night", text: "In a chase you can always roll Wits, whatever the ground." },
      { key: "wiseWoman", name: "Wise Woman", text: "A Cost on your Wits roll is never “lose a Turn”." },
    ],
    weakness: { name: "Rowan", timing: "soon", text: "A sprig of rowan, the old charm against witches: somebody’s grandmother always has one." },
    tell: { name: "A Black Cat", text: "A black cat follows her everywhere and stares at people." },
  },
  {
    key: "jekyll-hyde", name: "Jekyll & Hyde", duty: "librarian", dice: { brawn: 4, nimble: 6, sly: 8, charm: 12, wits: 10 },
    signature: { name: "The Draught", effect: "form", text: "change form, Jekyll to Hyde or back, before one of your rolls; the new form lasts until the next draught. He starts each raid as Jekyll. When the Monster shows on one of Jekyll’s rolls, Hyde takes over, free.", rule: "Before one of your rolls, change form: Jekyll to Hyde or back (each has its own dice). The new form lasts until the next draught. Each raid starts with Jekyll. When the Monster shows on one of Jekyll’s rolls, that roll stands and Hyde takes over straight after it, free, until a draught changes him back." },
    gift: {
      name: "The Other Self",
      versions: [
        { key: "doctorsBag", name: "Doctor’s Bag", effect: "raise", text: "The right instrument for the job.", default: true },
        { key: "pillarOfSociety", name: "Pillar of Society", effect: "hidden", note: "On Jekyll’s rolls, Hyde still takes over if the Monster shows.", text: "A respectable doctor having a funny turn." },
        { key: "trample", name: "Trample", effect: "open", trait: "brawn", note: "Your Brawn is a d4 as Jekyll, a d12 as Hyde.", text: "Hyde doesn’t wait to be let in." },
      ],
    },
    perks: [
      { key: "practisedHand", name: "Practised Hand", text: "Changing back to Jekyll costs no charge.", default: true },
      { key: "steadyNerves", name: "Steady Nerves", text: "On Jekyll’s rolls, Hyde takes over only if the Monster beats your trait die by 2 or more. Beating it by 1 still shows: Suspicion +2." },
      { key: "bruteStrength", name: "Brute Strength", text: "As Hyde, carrying doesn’t make your Nimble smaller." },
    ],
    weakness: { name: "A Familiar Face", timing: "soon", text: "Someone in the mob recognises the good doctor." },
    tell: { name: "The Wrong Hand", text: "One hand a gentleman’s, the other hairy and knotted." },
    forms: { jekyll: { brawn: 4, nimble: 6, sly: 8, charm: 12, wits: 10 }, hyde: { brawn: 12, nimble: 10, sly: 8, charm: 4, wits: 6 } },
  },
].map((e) => Object.freeze(e)));

/**
 * C10: the Castle Duties, one per kind of shopping-list item (a d6 in this order).
 * Edge: at a location whose list item is your Duty's kind, your trait die is one size
 * larger on your own rolls there (it counts as the roll's one raise, R2). No two
 * Entities in a party share a Duty (R8); if two defaults clash, the second rolls again.
 */
DGF.duties = Object.freeze([
  { key: "cook", name: "Cook", kind: "food and drink", where: "the baker, the butcher, the tavern cellar", role: "keeps the castle fed and knows every kitchen door" },
  { key: "gardener", name: "Gardener", kind: "plants and seeds", where: "the market garden, the florist, the seed merchant", role: "knows what grows where, and what’s poisonous" },
  { key: "librarian", name: "Librarian", kind: "books and paper", where: "the bookseller, the printer, the schoolhouse", role: "reads the town’s notices and signs" },
  { key: "butler", name: "Butler", kind: "silver, china and linen", where: "the silversmith, the china shop, the laundry", role: "knows how fine houses run, and where they keep the good spoons" },
  { key: "handyman", name: "Handyman", kind: "tools and hardware", where: "the smithy, the ironmonger, the carpenter", role: "knows how locks and hinges work" },
  { key: "tailor", name: "Tailor", kind: "cloth and costumes", where: "the draper, the tailor, the hatter", role: "keeps everyone’s disguises in one piece" },
].map((d) => Object.freeze(d)));

/** C14: the d66 shopping table: a d6 for the kind (in Castle Duty order), a d6 for the item. Only the kind matters to the rules. */
DGF.shoppingTable = Object.freeze([
  { duty: "cook", items: ["a wheel of strong cheese", "a side of bacon", "a cask of red wine (“for the guests”)", "a sack of flour", "a jar of honey", "the wedding cake in the shop window"] },
  { duty: "gardener", items: ["seed potatoes", "a pot of nightshade (purely ornamental)", "rose bushes for the graveyard", "turnip seed for next year’s lanterns", "a crate of lilies", "mushroom spawn for the cellar"] },
  { duty: "librarian", items: ["this week’s newspapers", "black-edged writing paper", "a cookbook “for the guests”", "ink and sealing wax", "an almanac with next year’s moons", "a book of etiquette"] },
  { duty: "butler", items: ["the silver spoons", "a tea service", "bed linen", "a lace tablecloth", "a pair of candlesticks", "a gravy boat"] },
  { duty: "handyman", items: ["a box of nails", "a new lock for the dungeon", "hinges that creak properly", "a lamp and a can of oil", "a coil of rope", "a length of good chain"] },
  { duty: "tailor", items: ["a bolt of black velvet", "bandages, lots", "a top hat", "a new cape", "knitting wool", "boots in a very large size"] },
].map((r) => Object.freeze({ duty: r.duty, items: Object.freeze(r.items) })));

/** C16: the d6 furniture table (the piece standing at one of the list's locations, and its size). */
DGF.furniture = Object.freeze([
  { key: "armchair", name: "A wingback armchair", size: "bulky" },
  { key: "mirror", name: "A gilt mirror", size: "bulky" },
  { key: "armour", name: "A suit of armour", size: "bulky" },
  { key: "bear", name: "A stuffed bear", size: "bulky" },
  { key: "clock", name: "A grandfather clock", size: "huge" },
  { key: "bed", name: "A four-poster bed", size: "huge" },
].map((f) => Object.freeze(f)));

/** C16 (optional campaign rules): each piece brought home is an upgrade worth one extra charge to one Entity per raid; the castle holds three. */
DGF.campaign = Object.freeze({ chargesPerUpgrade: 1, maxUpgrades: 3 });

/**
 * C17: rolling a town. Bands are [lowest, highest, result] on the die named.
 * Obstacles at a location (d20), each obstacle's Difficulty (d20), watched on this
 * d10 face or lower, and the ceiling on Difficulty-12 obstacles per town (extras rerolled).
 */
DGF.townDice = Object.freeze({
  obstacles: Object.freeze({
    easy: [[1, 10, 1], [11, 18, 2], [19, 20, 3]],
    standard: [[1, 6, 1], [7, 15, 2], [16, 20, 3]],
    hard: [[1, 4, 1], [5, 13, 2], [14, 20, 3]],
  }),
  difficulty: Object.freeze({
    easy: [[1, 3, 6], [4, 13, 8], [14, 19, 10], [20, 20, 12]],
    standard: [[1, 3, 6], [4, 13, 8], [14, 19, 10], [20, 20, 12]],
    hard: [[1, 8, 8], [9, 17, 10], [18, 20, 12]],
  }),
  watchedOn: Object.freeze({ easy: 4, standard: 5, hard: 6 }),
  twelves: Object.freeze({ easy: 1, standard: 1, hard: 2 }),
});

/**
 * C18: the d20 obstacle table. `quiet` is the trait that gets past it without a fuss; `loud`, if any, is the loud
 * way (Suspicion +1 whatever the result); `group`: everyone there rolls for themselves. Every trait is the quiet
 * way four times. A location's second way in is rolled again until its quiet trait differs.
 */
DGF.obstacleTable = Object.freeze([
  { key: "trapdoor", name: "A heavy cellar trapdoor", quiet: "brawn" },
  { key: "tugOfWar", name: "A tug-of-war across the lane", quiet: "brawn", group: true },
  { key: "cart", name: "A cart blocking the alley", quiet: "brawn", loud: "nimble", loudText: "scramble over the load" },
  { key: "backGate", name: "A bolted back gate", quiet: "brawn", quietText: "lift it off its hinges", loud: "charm", loudText: "shout “Delivery!” until someone opens it" },
  { key: "gardenWall", name: "A high garden wall", quiet: "nimble", loud: "brawn", loudText: "through the gate, lock and all" },
  { key: "window", name: "A shuttered window", quiet: "nimble", loud: "brawn", loudText: "force the shutters" },
  { key: "rooftops", name: "The rooftops", quiet: "nimble", group: true },
  { key: "drainpipe", name: "A rickety drainpipe", quiet: "nimble" },
  { key: "frontDoor", name: "A locked front door", quiet: "sly", quietText: "pick the lock", loud: "brawn", loudText: "kick it in" },
  { key: "neighbour", name: "A nosy neighbour at her window", quiet: "sly", loud: "wits", loudText: "a false alarm: “Your cat’s on the roof!”" },
  { key: "shopFloor", name: "A crowded shop floor", quiet: "sly", group: true },
  { key: "geese", name: "A muddy yard full of geese", quiet: "sly", loud: "nimble", loudText: "run for it, honking" },
  { key: "shopkeeper", name: "The shopkeeper behind the counter", quiet: "charm", loud: "sly", loudText: "snatch it from under her nose" },
  { key: "dog", name: "A guard dog", quiet: "charm", quietText: "a biscuit and a pat", loud: "nimble", loudText: "outrun it, barking" },
  { key: "doorman", name: "A doorman checking invitations", quiet: "charm", loud: "wits", loudText: "a forged invitation that fools nobody for long" },
  { key: "children", name: "Children in costumes who want a closer look", quiet: "charm", group: true },
  { key: "strongbox", name: "A locked strongbox", quiet: "wits", quietText: "work out the catch", loud: "charm", loudText: "sweet-talk the clerk into opening it" },
  { key: "backRoom", name: "A dark, cluttered back room", quiet: "wits", loud: "sly", loudText: "rummage through everything" },
  { key: "watchman", name: "The night watchman on his round", quiet: "wits", quietText: "time his round" },
  { key: "stalls", name: "A maze of festival stalls", quiet: "wits", group: true },
].map((o) => Object.freeze(o)));

/** C19: the villagers (flavour only): a d6 for who it is, a d6 for what they're doing. */
DGF.villagers = Object.freeze({
  who: Object.freeze(["The baker’s wife", "The night watchman", "A gang of children", "The vicar", "The mayor, in his best costume", "Old Granny Mott, who has seen it all before"]),
  doing: Object.freeze(["Looking for a lost cat", "Tipsy from the cider", "Judging the costume contest", "Carrying a lantern and a pitchfork “for the parade”", "Gossiping, loudly", "Practising the bells"]),
});

/** C12: the d6 chase table; one roll each round for everyone in the chase (the traits that work there). */
DGF.chaseTable = Object.freeze([
  { key: "crowdedSquare", name: "The crowded square", text: "Lose yourself in the crowd, or bluff your way through.", traits: ["sly", "charm"] },
  { key: "backAlleys", name: "Back alleys", text: "Duck, dodge, double back.", traits: ["nimble", "sly"] },
  { key: "marketStalls", name: "The market stalls", text: "Overturn a cart, vault a stall.", traits: ["brawn", "nimble"] },
  { key: "rooftops", name: "Over the rooftops", text: "Climb, jump, find a way down.", traits: ["nimble", "wits"] },
  { key: "parade", name: "The festival parade", text: "Join in: you’re in costume, after all.", traits: ["charm", "sly"] },
  { key: "deadEnd", name: "A dead end", text: "Break through, or think fast.", traits: ["brawn", "wits"] },
].map((r) => Object.freeze(r)));

/** C13: the festival, and a d6 table of local customs (flavour only, no rules). */
DGF.festival = Object.freeze({
  name: "Lantern Night",
  customs: Object.freeze([
  { key: "lanterns", text: "Turnip lanterns in every window." },
  { key: "parade", text: "A costume parade through the square at midnight." },
  { key: "maskedBall", text: "A masked ball at the mayor’s house." },
  { key: "pies", text: "Pies left on doorsteps “for the wanderers”." },
  { key: "bonfire", text: "A bonfire in the square, and a straw monster burned at dawn." },
  { key: "bells", text: "Bells rung every hour to keep the real monsters away. They never work." },
  ].map((c) => Object.freeze(c))),
});

/** C4: a Tell check is a d6; on this or higher a Tell goes off (whose: roll among the Entities arriving). */
DGF.tell = Object.freeze({ die: 6, goesOffOn: 4 });

/** C3: when the mob brings a Weakness. "soon" bites from this round of a chase (1-based). */
DGF.weaknessTimings = Object.freeze(["always", "soon"]); // B3: no Entity had Dawn timing; the line was dropped
DGF.weaknessSoonRound = 3;

/**
 * Chapter 2 Perks that bend a roll, as data for the rules logic (module/logic/roll-plan.mjs).
 * Each line restates its Perk's text; nothing here is new. `showMargin` / `formMargin`:
 * how far the Monster die must beat the trait die (1 = "higher", 2 = "by 2 or more").
 */
DGF.perkRules = Object.freeze({
  hypnoticEyes: Object.freeze({ trait: "charm", showMargin: 2 }), // On Charm rolls, the Monster shows only if it beats your trait die by 2 or more.
  oldMoney: Object.freeze({ trait: "charm", noCost: "suspicion" }), // A Cost on a Charm roll is never Suspicion +1.
  tireless: Object.freeze({ carryNimble: false }), // Carrying doesn’t make your Nimble smaller.
  patienceOfAges: Object.freeze({ noCost: "loseTurn" }), // “Lose a Turn” is never your Cost.
  keeperOfTreasures: Object.freeze({ noCost: "drop" }), // “Drop an item” is never your Cost.
  shortcut: Object.freeze({ exitEase: 2 }), // The way out’s Difficulty is 2 lower when you roll it.
  outOfSight: Object.freeze({ caughtOnlyCarrying: true, withYou: true }), // V17: Trouble gets you caught only while you or anyone in the same place carries loot or furniture.
  lightStep: Object.freeze({ loud: 0 }), // The loud way costs you no Suspicion.
  rattle: Object.freeze({ monsterShows: 1 }), // The Monster showing on your roll is Suspicion +1, not +2.
  wiseWoman: Object.freeze({ trait: "wits", noCost: "loseTurn" }), // A Cost on your Wits roll is never “lose a Turn”.
  practisedHand: Object.freeze({ freeDraughtTo: "jekyll" }), // Changing back to Jekyll costs no charge.
  steadyNerves: Object.freeze({ formMargin: 2 }), // Hyde takes over only if the Monster beats your trait die by 2 or more.
  bruteStrength: Object.freeze({ form: "hyde", carryNimble: false }), // As Hyde, carrying doesn’t make your Nimble smaller.
  fetch: Object.freeze({ finalLead: 3, partyExitEase: 1 }), // B2: a final flight you're in starts at Lead 3; B5: the way out's Difficulty is 1 lower while you're there.
  // Perks that bend a chase, the lock-up or a Tell check (module/logic/chase.mjs, lockup.mjs, checks.mjs; chaseRaise: roll-plan.mjs):
  wallCrawler: Object.freeze({ chaseTrait: "nimble", chaseRaise: "nimble" }), // In a chase you can always roll Nimble, and your Nimble die is one size bigger there, the roll's one raise (2026-10-20).
  flyByNight: Object.freeze({ chaseTrait: "wits" }), // In a chase you can always roll Wits.
  nightRunner: Object.freeze({ localLead: 2, aloneOnly: true }), // F14: when you flee alone, your local chase starts at Lead 2.
  fearTheCurse: Object.freeze({ localMobEase: 1, aloneOnly: true }), // F14: when you flee alone, the mob's Difficulty in your local chase is 1 lower.
  spectral: Object.freeze({ groupPass: true }), // V19: past group obstacles without rolling, unless you carry loot or furniture.
  alreadyDead: Object.freeze({ corneredLosesTurn: true }), // Cornered in a local chase, you lose your next Turn instead of being captured (V5: if the chase's rise brings the Limit, you join the flight).
  builtToLast: Object.freeze({ slipOnCost: true }), // You slip free from the lock-up on a Success or a Cost.
  hiddenPockets: Object.freeze({ keepLoot: true }), // Captured, you keep the loot you carry (not furniture: V16).
  familiarsWarning: Object.freeze({ tellSecondDie: true }), // When you arrive somewhere that gets a Tell check, a Tell goes off only if a second d6 also rolls 4–6.
});

/** Chapter 4, Getting Out: the way out is one watched obstacle — Sly or Nimble, or Brawn the loud way. */
DGF.wayOut = Object.freeze({ quiet: Object.freeze(["sly", "nimble"]), loud: Object.freeze(["brawn"]) });

/**
 * Chapter 6, Captured: the lock-up. Rescue: Sly, or Brawn the loud way, always watched, at the lock-up
 * Difficulty. Slipping free: Sly or Nimble, or Brawn the loud way, at the lock-up Difficulty (T8).
 */
DGF.lockup = Object.freeze({
  rescue: Object.freeze({ quiet: Object.freeze(["sly"]), loud: Object.freeze(["brawn"]) }),
  slip: Object.freeze({ quiet: Object.freeze(["sly", "nimble"]), loud: Object.freeze(["brawn"]) }),
});

/**
 * Chapter 6: how a chase ends. "gaveUp": every runner of a local chase gave up (D2: captured, no roll); "ended": the
 * hunt started during a local chase (F25: it joins the final flight); "dropped": the Storyteller called it off.
 */
DGF.chaseOutcomes = Object.freeze(["escaped", "cornered", "gaveUp", "ended", "dropped"]);

/** P3: the four Costs the Storyteller picks from, in the book's order. */
DGF.costs = Object.freeze(["suspicion", "drop", "loseTurn", "smaller"]);

/** An Entity during a raid: free, or held at the lock-up (Chapter 6). */
DGF.statuses = Object.freeze(["active", "captured"]);

/** CORE-RULES Rolling 2: the second die. */
DGF.second = Object.freeze({ mask: 6, monster: 10 });

/** P1: an obstacle's Difficulty is one of these numbers (R7: just numbers; the keys are names for the code, never shown). */
DGF.difficulty = Object.freeze({ easy: 6, standard: 8, hard: 10, daunting: 12 });

/** CORE-RULES Abilities: the four standard effects; "open" is the ability's trait at this much lower Difficulty (S10). */
DGF.effects = Object.freeze(["raise", "switch", "hidden", "open"]);
DGF.openApproachEase = 2;

/**
 * CORE-RULES Suspicion: what raises it. One roll raises it once, by its biggest trigger, except an overdraw, which
 * always adds its +2 on top (D3); a local chase raises it once, when it ends (D1).
 */
DGF.suspicion = Object.freeze({ trouble: 1, monsterShows: 2, tell: 1, overdraw: 2, loud: 1, cost: 1, furniture: 1 });

/** B2 (Chapters 4, 5 and 8): the furniture's extra obstacle is 2 harder than rolled (at most 12); carrying a piece raises Suspicion each Turn (DGF.suspicion.furniture). */
DGF.furnitureObstacle = Object.freeze({ harder: 2, max: 12 });

/** P8 + Grand Year: the year's results, worst to best (Forked stands apart). */
DGF.results = Object.freeze(["bust", "partial", "win", "grand"]);

/** C15: the epilogue (story only): one line for the result, then one for each kind of item (by Castle Duty) that didn't come home. */
DGF.epilogue = Object.freeze({
  year: Object.freeze({
    grand: "A year of plenty. The new piece goes in the great hall, and everyone pretends it was always there.",
    win: "Full larders, warm fires. The castle creaks happily through another year.",
    partial: "The castle gets by, just. Someone has to sleep in the draughty tower.",
    bust: "A long, thin year, and a lot of arguing about whose fault it was.",
    forked: "The town tells the story for years. Next Lantern Night, the bells ring a little louder.",
  }),
  missing: Object.freeze({
    cook: "Turnip soup every night until spring.",
    gardener: "Nothing grows but nettles, and the nettles win.",
    librarian: "Nobody knows what the town is saying, or what day it is.",
    butler: "Dinner is served on old coffin lids.",
    handyman: "Every door in the castle creaks, sticks or falls off.",
    tailor: "Next year’s disguises are held together with string and hope.",
  }),
});

/** S9 / S10 starting numbers, retuned in B1 (lists 4 / 5 / 5, Hard way out 10) and B3 (Easy and Standard Limits 11, flights escaping at 5); Limits 9 / 10 / 13 after the outside review's rule package (F12, 2026-10-20). */
DGF.charges = 3;
DGF.turns = 12;
DGF.lead = Object.freeze({ localStart: 1, localEscape: 4, finalStart: 2, finalEscape: 6 });
DGF.localMob = Object.freeze({ base: 8, perSuspicion: 0.5, max: 12 }); // B3: base 8 (was 10)
DGF.labels = Object.freeze({
  easy: Object.freeze({ items: 4, essentials: [1], limit: 9, finalEscape: 5, exit: 6, finalMob: 10, lockup: 10, mix: { 6: 0.15, 8: 0.5, 10: 0.3, 12: 0.05 } }),
  standard: Object.freeze({ items: 5, essentials: [1, 2], limit: 10, finalEscape: 5, exit: 8, finalMob: 11, lockup: 10, mix: { 6: 0.15, 8: 0.5, 10: 0.3, 12: 0.05 } }),
  hard: Object.freeze({ items: 5, essentials: [2], limit: 13, finalEscape: 6, exit: 10, finalMob: 11, lockup: 10, mix: { 8: 0.4, 10: 0.45, 12: 0.15 } }),
});
